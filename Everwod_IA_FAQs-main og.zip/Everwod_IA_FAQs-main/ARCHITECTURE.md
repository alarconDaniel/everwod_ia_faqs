# Arquitectura Tecnica

## Objetivo

El sistema analiza conversaciones historicas normalizadas en PostgreSQL para detectar preguntas recurrentes por workspace, sugerir FAQs nuevas o mejoras y permitir validacion humana antes de convertirlas en FAQs persistentes.

## Modelo de datos

La fuente operativa del backend es `faq_mvp`, no las tablas crudas antiguas.

- `workspaces`, `agents`, `conversations`, `messages`: base conversacional normalizada.
- `existing_faqs`: FAQs heredadas desde `agent_faqs` y FAQs aprobadas desde el MVP.
- `pipeline_runs`: auditoria de cada ejecucion manual o programada.
- `pipeline_metrics`: metricas numericas de la corrida.
- `question_clusters`: grupos semanticos detectados.
- `faq_candidates`: sugerencias revisables.
- `faq_candidate_examples`: mensajes reales que soportan cada sugerencia.
- `message_embeddings`: embeddings de mensajes de usuario usados como evidencia.
- `faq_validation_events`: historial de cambios de estado y comentarios humanos.

`company_id` se mantiene como alias de `workspace_id` en las respuestas API para compatibilidad.

## Flujo

```mermaid
flowchart LR
    A["faq_mvp.messages"] --> B["Ingesta: pares usuario/asistente"]
    B --> C["Filtros FAQ y limpieza PII"]
    C --> D["Embeddings locales"]
    D --> E["DBSCAN por workspace"]
    E --> F["Deduplicacion contra existing_faqs"]
    F --> G["faq_candidates + examples + clusters"]
    G --> H["Validacion humana"]
    H --> I["faq_validation_events"]
    H --> J["Promocion approved a existing_faqs"]
```

## Servicios

### Ingesta

`ingest_service.py` consulta `faq_mvp.messages` unido con `conversations` y `workspaces`. Solo procesa `role IN ('user', 'assistant')` con `content_text` no vacio. En cada conversacion empareja el ultimo mensaje del usuario con la siguiente respuesta del asistente y conserva:

- `workspace_id` / `company_id`;
- `company_name`;
- `agent_id`;
- `conversation_pk`;
- `conversation_id`;
- `user_message_pk`;
- `assistant_message_pk`;
- textos y timestamps.

### Sugerencias

`suggestion_service.py` crea una fila `running` en `pipeline_runs`, procesa mensajes recientes y finaliza la corrida como `succeeded` o `failed`.

El pipeline:

1. Filtra saludos, respuestas triviales, correos, telefonos y preguntas operativas no FAQ.
2. Genera embeddings locales con `all-MiniLM-L6-v2` o fallback hash.
3. Agrupa por workspace con DBSCAN.
4. Calcula soporte del cluster y silhouette score si hay suficientes clusters.
5. Deduplica contra `faq_mvp.existing_faqs`.
6. Redacta una respuesta neutra con Qwen local si esta habilitado; si no, usa fallback historico saneado.
7. Persiste clusters, candidatos, ejemplos, embeddings y metricas.

Las respuestas se limpian con `clean_faq_answer()` para quitar saludos, nombres, frases conversacionales y PII.

### Validacion

`validation_service.py` trabaja contra la base:

- `GET /suggestions`: lista candidatos con filtros por `status`, `workspace_id` y `agent_id`.
- `GET /validations`: lista eventos humanos.
- `POST /validate`: actualiza estado del candidato e inserta evento.

Estados validos:

- `approved`
- `rejected`
- `needs_review`

Al aprobar, el servicio promueve el candidato a `faq_mvp.existing_faqs` usando `candidate_id` como `faq_id`. Esta decision evita crear una segunda tabla de FAQs activas y hace que futuras corridas dedupliquen automaticamente contra lo aprobado. La promocion falla con error claro si falta `agent_id` o `suggested_answer`.

### Scheduler

`scheduler.py` ejecuta `run_suggestion_pipeline()` semanalmente por defecto:

```env
FAQ_SCHEDULE_INTERVAL_DAYS=7
```

El job usa el mismo flujo persistente que `POST /suggest`, por lo que siempre deja `pipeline_runs` y `pipeline_metrics`.

### Frontend

`frontend/` es una app React/Vite conectada a:

- `POST /ingest`
- `POST /suggest`
- `GET /suggestions`
- `POST /validate`
- `GET /validations`

CORS se configura con `CORS_ALLOW_ORIGINS`, incluyendo `http://localhost:5173` para desarrollo.

## Modelos locales

Embeddings:

- Por defecto: `all-MiniLM-L6-v2`.
- Alternativa: `FAQ_EMBEDDING_BACKEND=hash`, sin descargas ni dependencias semanticas.

Generacion:

- Opcion local: `Qwen/Qwen2.5-0.5B-Instruct`.
- Desactivada por defecto para reproducibilidad.
- Fallback: respuesta historica del cluster, anonimizada y convertida a tono FAQ.

No se consumen APIs externas pagas.

## Persistencia e idempotencia

- Cada corrida crea `pipeline_runs`.
- Los embeddings usan unicidad por `(message_pk, embedding_model)`.
- Los candidatos se buscan por workspace, agente y pregunta normalizada para evitar duplicados por corridas repetidas.
- Las sugerencias aprobadas se vuelven FAQs activas en `existing_faqs`, cerrando el ciclo de deduplicacion.

## Riesgos y mejoras futuras

- Resolver conversaciones sin `agent_id` con reglas de negocio mas fuertes.
- Evaluar HDBSCAN o clustering jerarquico si DBSCAN queda muy sensible.
- Agregar `pgvector` cuando el ambiente lo permita.
- Crear evaluacion experimental con muestra etiquetada por humanos.
- Unificar servicios FastAPI en un gateway si se despliega a produccion.
