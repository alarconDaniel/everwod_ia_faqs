import { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { MetricsCards } from './components/MetricsCards';
import { FiltersBar } from './components/FiltersBar';
import { SuggestionList } from './components/SuggestionList';
import { ValidationModal } from './components/ValidationModal';
import { ValidationHistory } from './components/ValidationHistory';
import { EmptyState } from './components/EmptyState';
import { LoadingState } from './components/LoadingState';
import { ErrorState } from './components/ErrorState';
import { Toast } from './components/Toast';

import { useSuggestions } from './hooks/useSuggestions';
import { useValidations } from './hooks/useValidations';
import { Suggestion, ValidationStatus } from './types/faq';

export default function App() {
  const { data, isLoading, isGenerating, error, fetchSuggestions, generateSuggestions } = useSuggestions();
  const { validations, validateSuggestion, isSubmitting } = useValidations();

  // Filters State
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ValidationStatus | 'all'>('all');
  const [companyFilter, setCompanyFilter] = useState('all');

  // Modal State
  const [selectedSuggestion, setSelectedSuggestion] = useState<Suggestion | null>(null);

  // Toast State
  const [toast, setToast] = useState<{ isVisible: boolean; message: string; type: 'success' | 'error' }>({
    isVisible: false,
    message: '',
    type: 'success'
  });

  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ isVisible: true, message, type });
  };

  const handleValidate = async (req: any) => {
    try {
      await validateSuggestion(req);
      // Validated successfully, fetch the updated suggestions
      await fetchSuggestions();
      showToast('Sugerencia evaluada exitosamente', 'success');
    } catch (e) {
      showToast('No se pudo enviar la evaluación', 'error');
      // Re-throw to prevent modal from closing if we want
      throw e;
    }
  };

  const companies = useMemo(() => {
    if (!data?.suggestions) return [];
    return Array.from(new Set(data.suggestions.map(s => s.company_name))).sort();
  }, [data]);

  const filteredSuggestions = useMemo(() => {
    if (!data?.suggestions) return [];
    
    return data.suggestions.filter(s => {
      // Search
      const textToSearch = `${s.question} ${s.answer}`.toLowerCase();
      if (search && !textToSearch.includes(search.toLowerCase())) return false;
      
      // Status
      if (statusFilter !== 'all' && s.status !== statusFilter) return false;
      
      // Company
      if (companyFilter !== 'all' && s.company_name !== companyFilter) return false;
      
      return true;
    });
  }, [data, search, statusFilter, companyFilter]);

  return (
    <div className="h-screen bg-slate-50 flex flex-col font-sans overflow-hidden">
      <Header onGenerate={generateSuggestions} isGenerating={isGenerating} />
      
      <main className="flex-1 flex overflow-hidden p-6 gap-6">
        {/* Left column */}
        <aside className="w-[280px] flex flex-col gap-6 overflow-y-auto pb-4 hide-scrollbar shrink-0">
          <Hero />
          {error && <ErrorState message={error} onRetry={fetchSuggestions} />}
          {data && <MetricsCards metrics={data} />}
          <FiltersBar 
            search={search}
            setSearch={setSearch}
            statusFilter={statusFilter}
            setStatusFilter={setStatusFilter}
            companies={companies}
            companyFilter={companyFilter}
            setCompanyFilter={setCompanyFilter}
          />
        </aside>

        {/* Center column */}
        <section className="flex-1 flex flex-col gap-4 overflow-hidden relative">
          <div className="flex items-center justify-between shrink-0">
            <h3 className="font-bold text-slate-800">Sugerencias {data ? `(${data.suggestions.length})` : ''}</h3>
          </div>

          <div className="flex-1 overflow-y-auto pb-6 pr-2 hide-scrollbar">
            {isLoading ? (
              <LoadingState />
            ) : !data || data.suggestions.length === 0 ? (
              <EmptyState />
            ) : (
              <SuggestionList 
                suggestions={filteredSuggestions} 
                onValidate={(s) => setSelectedSuggestion(s)} 
              />
            )}
          </div>
        </section>

        {/* Right column */}
        <aside className="w-[280px] bg-white border border-slate-200 rounded-2xl flex flex-col shadow-sm overflow-hidden shrink-0">
          <ValidationHistory validations={validations} />
        </aside>
      </main>

      <footer className="h-12 bg-indigo-50 border-t border-indigo-100 px-8 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></span>
          <p className="text-xs font-medium text-indigo-700 italic">Servicios FastAPI conectados</p>
        </div>
        <div className="text-[10px] font-bold text-indigo-300 uppercase">
          Everwod Technologies
        </div>
      </footer>

      <ValidationModal
        suggestion={selectedSuggestion}
        isOpen={!!selectedSuggestion}
        onClose={() => setSelectedSuggestion(null)}
        onSubmit={handleValidate}
        isSubmitting={isSubmitting}
      />

      <Toast 
        {...toast} 
        onClose={() => setToast(prev => ({ ...prev, isVisible: false }))} 
      />
    </div>
  );
}
