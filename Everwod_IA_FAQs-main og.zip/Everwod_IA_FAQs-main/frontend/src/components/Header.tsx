import { Brain, Loader2, RefreshCw } from 'lucide-react';

interface HeaderProps {
  onGenerate: () => void;
  isGenerating: boolean;
}

export function Header({ onGenerate, isGenerating }: HeaderProps) {
  return (
    <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between shrink-0">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center">
          <Brain className="w-5 h-5 text-white" />
        </div>
        <div>
          <h1 className="text-lg font-bold text-slate-900 leading-none">Everwod FAQ Intelligence</h1>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">Panel de revision humana</p>
        </div>
      </div>
      <button
        onClick={onGenerate}
        disabled={isGenerating}
        className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded-lg shadow-sm transition-colors flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
      >
        {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
        {isGenerating ? 'Generando...' : 'Generar nuevas sugerencias'}
      </button>
    </header>
  );
}
