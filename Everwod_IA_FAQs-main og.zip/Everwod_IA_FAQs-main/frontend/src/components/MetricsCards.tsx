import { SuggestionsResponse } from '../types/faq';

interface MetricsCardsProps {
  metrics: Omit<SuggestionsResponse, 'suggestions'> | null;
}

export function MetricsCards({ metrics }: MetricsCardsProps) {
  if (!metrics) return null;

  return (
    <div className="grid grid-cols-2 gap-3 shrink-0">
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-tighter">Empresas</p>
        <p className="text-xl font-bold text-slate-800">{metrics.company_count}</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-tighter">Clusters</p>
        <p className="text-xl font-bold text-slate-800">{metrics.cluster_count}</p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-tighter">Ejemplos</p>
        <p className="text-xl font-bold text-slate-800">
          {metrics.total_examples >= 1000 ? `${(metrics.total_examples / 1000).toFixed(1)}k` : metrics.total_examples}
        </p>
      </div>
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
        <p className="text-[10px] uppercase font-bold text-slate-400 tracking-tighter">Silhouette</p>
        <p className="text-xl font-bold text-indigo-600">
          {metrics.silhouette_score === null ? 'N/D' : metrics.silhouette_score.toFixed(2)}
        </p>
      </div>
    </div>
  );
}
