import { useState, useCallback, useEffect } from 'react';
import { faqApi } from '../services/faqApi';
import { SuggestionsResponse } from '../types/faq';

export function useSuggestions() {
  const [data, setData] = useState<SuggestionsResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchSuggestions = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const response = await faqApi.getSuggestions();
      setData(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido al cargar sugerencias');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const generateSuggestions = useCallback(async () => {
    setIsGenerating(true);
    setError(null);
    try {
      await faqApi.ingest({ limit: 15000, since_days: 90 });
      const response = await faqApi.suggest();
      setData(response);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al generar sugerencias');
    } finally {
      setIsGenerating(false);
    }
  }, [fetchSuggestions]);

  useEffect(() => {
    fetchSuggestions();
  }, [fetchSuggestions]);

  return {
    data,
    isLoading,
    isGenerating,
    error,
    fetchSuggestions,
    generateSuggestions
  };
}
