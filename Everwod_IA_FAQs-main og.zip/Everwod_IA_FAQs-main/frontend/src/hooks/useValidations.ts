import { useState, useCallback, useEffect } from 'react';
import { faqApi } from '../services/faqApi';
import { ValidationRecord, ValidationRequest } from '../types/faq';

export function useValidations() {
  const [validations, setValidations] = useState<ValidationRecord[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchValidations = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await faqApi.getValidations();
      setValidations(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al cargar validaciones');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const validateSuggestion = useCallback(async (req: ValidationRequest) => {
    setIsSubmitting(true);
    setError(null);
    try {
      await faqApi.validate(req);
      await fetchValidations(); // Refrescar historial
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al validar sugerencia');
      throw err;
    } finally {
      setIsSubmitting(false);
    }
  }, [fetchValidations]);

  useEffect(() => {
    fetchValidations();
  }, [fetchValidations]);

  return {
    validations,
    isLoading,
    isSubmitting,
    error,
    fetchValidations,
    validateSuggestion
  };
}
