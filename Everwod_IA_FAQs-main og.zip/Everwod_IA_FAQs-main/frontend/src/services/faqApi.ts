import { IngestRequest, SuggestionsResponse, ValidationRecord, ValidationRequest } from '../types/faq';
import { mockFaqApi } from './mockFaqApi';

const INGEST_API_URL = import.meta.env.VITE_INGEST_API_URL || 'http://127.0.0.1:8001';
const SUGGESTION_API_URL = import.meta.env.VITE_SUGGESTION_API_URL || 'http://127.0.0.1:8003';
const VALIDATION_API_URL = import.meta.env.VITE_VALIDATION_API_URL || 'http://127.0.0.1:8004';
const USE_MOCKS = import.meta.env.VITE_USE_MOCKS === 'true';

async function parseApiError(res: Response, fallback: string): Promise<Error> {
  try {
    const payload = await res.json();
    return new Error(payload.detail || fallback);
  } catch {
    return new Error(fallback);
  }
}

const realFaqApi = {
  ingest: async (req: IngestRequest): Promise<void> => {
    const res = await fetch(`${INGEST_API_URL}/ingest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    });
    if (!res.ok) throw await parseApiError(res, 'Error en ingesta');
  },

  suggest: async (): Promise<SuggestionsResponse> => {
    const res = await fetch(`${SUGGESTION_API_URL}/suggest`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ limit: 15000, since_days: 90 })
    });
    if (!res.ok) throw await parseApiError(res, 'Error al sugerir FAQs');
    return res.json();
  },

  getSuggestions: async (): Promise<SuggestionsResponse> => {
    const res = await fetch(`${SUGGESTION_API_URL}/suggestions`);
    if (!res.ok) throw await parseApiError(res, 'Error al obtener sugerencias');
    return res.json();
  },

  getValidations: async (): Promise<ValidationRecord[]> => {
    const res = await fetch(`${VALIDATION_API_URL}/validations`);
    if (!res.ok) throw await parseApiError(res, 'Error al obtener validaciones');
    return res.json();
  },

  validate: async (req: ValidationRequest): Promise<void> => {
    const res = await fetch(`${VALIDATION_API_URL}/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(req)
    });
    if (!res.ok) throw await parseApiError(res, 'Error en validacion');
  }
};

export const faqApi = USE_MOCKS ? mockFaqApi : realFaqApi;
