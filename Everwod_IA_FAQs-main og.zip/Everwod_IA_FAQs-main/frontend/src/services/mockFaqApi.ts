import { IngestRequest, Suggestion, SuggestionsResponse, ValidationRecord, ValidationRequest } from '../types/faq';

let mockSuggestions: Suggestion[] = [];
let mockValidations: ValidationRecord[] = [];
let hasIngested = false;

const generateMockSuggestions = (): Suggestion[] => [
  {
    id: 'uuid-1',
    company_id: '123',
    company_name: 'Gimnasio FitLife',
    workspace_id: 123,
    agent_id: '00000000-0000-0000-0000-000000000123',
    question: '¿Cómo puedo reservar una clase?',
    answer: 'Las clases pueden reservarse mediante la app o por el canal oficial de WhatsApp, segun disponibilidad del horario.',
    cluster_size: 24,
    support_examples: ['¿Cómo reservo una clase?', 'Quiero agendar una clase para mañana', '¿Puedo reservar por WhatsApp?'],
    cluster_score: 82.5,
    status: 'pending'
  },
  {
    id: 'uuid-2',
    company_id: '123',
    company_name: 'Gimnasio FitLife',
    workspace_id: 123,
    agent_id: '00000000-0000-0000-0000-000000000123',
    question: '¿Cuáles son los horarios de atención?',
    answer: 'Los horarios de atención deben confirmarse con el equipo del gimnasio antes de publicarse como FAQ definitiva.',
    cluster_size: 45,
    support_examples: ['¿A qué hora abren?', 'Horarios por favor', '¿Están abiertos los domingos?'],
    cluster_score: 95.0,
    status: 'pending'
  }
];

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

function buildSummary(): SuggestionsResponse {
  return {
    company_count: new Set(mockSuggestions.map(s => s.company_id)).size,
    cluster_count: mockSuggestions.length,
    total_examples: mockSuggestions.reduce((acc, curr) => acc + curr.cluster_size, 0),
    average_cluster_size: mockSuggestions.length > 0
      ? Math.round(mockSuggestions.reduce((acc, curr) => acc + curr.cluster_size, 0) / mockSuggestions.length)
      : 0,
    silhouette_score: mockSuggestions.length > 1 ? 0.74 : null,
    suggestions: mockSuggestions,
    run_id: 'mock-run'
  };
}

export const mockFaqApi = {
  ingest: async (_req: IngestRequest): Promise<void> => {
    await delay(800);
    hasIngested = true;
  },

  suggest: async (): Promise<SuggestionsResponse> => {
    await delay(1000);
    if (hasIngested && mockSuggestions.length === 0) {
      mockSuggestions = generateMockSuggestions();
    }
    return buildSummary();
  },

  getSuggestions: async (): Promise<SuggestionsResponse> => {
    await delay(300);
    return buildSummary();
  },

  getValidations: async (): Promise<ValidationRecord[]> => {
    await delay(250);
    return [...mockValidations].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  },

  validate: async (req: ValidationRequest): Promise<void> => {
    await delay(300);
    const suggestion = mockSuggestions.find(s => s.id === req.suggestion_id);
    if (!suggestion) {
      throw new Error('Suggestion not found');
    }
    const previousStatus = suggestion.status;
    suggestion.status = req.status;
    mockValidations.push({
      ...req,
      id: `val_${Date.now()}`,
      created_at: new Date().toISOString(),
      previous_status: previousStatus,
      question_summary: suggestion.question
    });
  }
};
