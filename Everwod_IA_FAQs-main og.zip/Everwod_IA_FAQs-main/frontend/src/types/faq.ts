export type ValidationStatus = 'pending' | 'approved' | 'rejected' | 'needs_review';

export interface Suggestion {
  id: string;
  company_id: string;
  company_name: string;
  workspace_id: number;
  agent_id?: string | null;
  question: string;
  answer: string;
  cluster_size: number;
  support_examples: string[];
  cluster_score: number;
  status: ValidationStatus;
  created_at?: string;
  updated_at?: string;
  run_id?: string | null;
}

export interface SuggestionsResponse {
  company_count: number;
  cluster_count: number;
  total_examples: number;
  average_cluster_size: number;
  silhouette_score: number | null;
  suggestions: Suggestion[];
  run_id?: string | null;
}

export interface ValidationRequest {
  suggestion_id: string;
  reviewer: string;
  status: 'approved' | 'rejected' | 'needs_review';
  notes?: string;
}

export interface ValidationRecord extends ValidationRequest {
  id: string;
  created_at: string;
  question_summary: string;
  previous_status?: ValidationStatus | null;
}

export interface IngestRequest {
  limit: number;
  since_days: number;
}
