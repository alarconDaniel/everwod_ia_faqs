import pytest
import suggestion_service as svc


@pytest.fixture(autouse=True)
def lightweight_models():
    svc.MODELS_READY = True
    svc.EMBEDDING_MODEL = None
    svc.ANSWER_GENERATOR = None
    svc.EMBEDDING_BACKEND_READY = "hash"


def test_candidate_filter_rejects_noise_and_accepts_business_question():
    assert not svc.is_good_faq_candidate("hola")
    assert not svc.is_good_faq_candidate("Gracias por la informacion")
    assert not svc.is_good_faq_candidate("mi correo es cliente@example.com")
    assert svc.is_good_faq_candidate("Quiero reservar una clase de cortesia")


def test_existing_faq_deduplicates_exact_normalized_question():
    assert svc.is_existing_faq(
        "¿Cómo puedo reservar una clase?",
        ["Como puedo reservar una clase"],
    )


def test_redacts_pii_from_examples():
    text = "Hola Juan Perez, escribe a cliente@example.com o al 300 123 4567"
    redacted = svc.redact_personal_data(text)

    assert "Juan Perez" not in redacted
    assert "cliente@example.com" not in redacted
    assert "300 123 4567" not in redacted
    assert "[correo]" in redacted
    assert "[telefono]" in redacted


def test_clean_faq_answer_removes_personal_greeting_and_name():
    answer = "Hola Juan, para tu día de cortesía te ayudamos a reservar por WhatsApp"

    cleaned = svc.clean_faq_answer(answer)

    assert "Hola" not in cleaned
    assert "Juan" not in cleaned
    assert "te ayudamos" not in cleaned.lower()
    assert cleaned.startswith("Para el día de cortesía")


def test_generate_answer_uses_historical_fallback_without_llm():
    svc.ANSWER_GENERATOR = None
    answer = svc.generate_answer(
        question="Quiero reservar una clase de cortesia",
        examples=["Quiero reservar una clase de cortesia"],
        historical_answers=["Hola Maria, para tu reserva te confirmamos disponibilidad por WhatsApp."],
        company_name="Empire Box",
    )

    assert "Hola" not in answer
    assert "Maria" not in answer
    assert "te confirmamos" not in answer.lower()
    assert answer.endswith(".")
