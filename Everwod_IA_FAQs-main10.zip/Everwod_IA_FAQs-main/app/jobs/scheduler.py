from datetime import datetime

from apscheduler.schedulers.blocking import BlockingScheduler

from app.api.ingest_service import ingest
from app.core.common import FAQ_INGEST_SOURCE, get_bool_env, get_int_env
from app.core.models import IngestRequest
from app.api.suggestion_service import run_suggestion_pipeline


FAQ_SCHEDULE_INTERVAL_DAYS = get_int_env("FAQ_SCHEDULE_INTERVAL_DAYS", 30)
FAQ_SCHEDULE_SINCE_DAYS = get_int_env("FAQ_SCHEDULE_SINCE_DAYS", 365)
FAQ_MONTHLY_RUN_INGEST = get_bool_env("FAQ_MONTHLY_RUN_INGEST", False)


def scheduled_pipeline() -> None:
    start = datetime.utcnow()
    print(f"[{start.isoformat()}] Iniciando pipeline mensual de FAQ automatica...")
    if FAQ_MONTHLY_RUN_INGEST:
        ingest_response = ingest(
            limit=None,
            since_days=FAQ_SCHEDULE_SINCE_DAYS,
            workspace_id=None,
            agent_id=None,
            dry_run=False,
            source=FAQ_INGEST_SOURCE,
        )
        print(f"  - Ingesta raw ejecutada: records_written={ingest_response.records_written}")

    request = IngestRequest(
        limit=None,
        since_days=FAQ_SCHEDULE_SINCE_DAYS,
        workspace_id=None,
        agent_id=None,
    )

    summary = run_suggestion_pipeline(request)

    print(f"  - Pipeline run: {summary.run_id}")
    print(f"  - Empresas analizadas: {summary.company_count}")
    print(f"  - Candidatos generados/actualizados: {summary.cluster_count}")
    print(f"  - Ejemplos candidatos: {summary.total_examples}")
    print(f"  - Silhouette: {summary.silhouette_score}")
    print(f"[{datetime.utcnow().isoformat()}] Pipeline completado.")


if __name__ == "__main__":
    scheduler = BlockingScheduler()
    scheduler.add_job(
        scheduled_pipeline,
        "interval",
        days=FAQ_SCHEDULE_INTERVAL_DAYS,
        next_run_time=datetime.now(),
    )

    print(f"Scheduler iniciado: el job se ejecutara cada {FAQ_SCHEDULE_INTERVAL_DAYS} dias.")

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("Scheduler detenido manualmente.")
