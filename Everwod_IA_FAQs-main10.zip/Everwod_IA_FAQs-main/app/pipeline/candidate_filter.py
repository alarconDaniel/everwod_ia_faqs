import sys as _sys

from app.api import suggestion_service as _impl
from app.api.suggestion_service import *  # noqa: F401,F403

_sys.modules[__name__] = _impl
