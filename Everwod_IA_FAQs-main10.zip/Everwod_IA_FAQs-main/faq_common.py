﻿"""Legacy compatibility facade for `app.core.common`."""

import sys as _sys

from app.core.common import *  # noqa: F401,F403
import app.core.common as _impl

_sys.modules[__name__] = _impl
