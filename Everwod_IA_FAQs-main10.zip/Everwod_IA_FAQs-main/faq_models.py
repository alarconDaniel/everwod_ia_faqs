﻿"""Legacy compatibility facade for `app.core.models`."""

import sys as _sys

from app.core.models import *  # noqa: F401,F403
import app.core.models as _impl

_sys.modules[__name__] = _impl
