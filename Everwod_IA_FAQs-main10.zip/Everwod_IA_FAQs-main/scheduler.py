﻿"""Legacy compatibility facade for `app.jobs.scheduler`."""

import sys as _sys

from app.jobs.scheduler import *  # noqa: F401,F403
import app.jobs.scheduler as _impl

_sys.modules[__name__] = _impl
