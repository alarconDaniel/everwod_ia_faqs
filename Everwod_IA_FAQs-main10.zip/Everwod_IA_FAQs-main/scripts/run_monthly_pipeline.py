import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from app.api.ingest_service import ingest
from app.api.suggestion_service import run_suggestion_pipeline
from app.core.common import FAQ_INGEST_SOURCE, get_bool_env
from app.core.models import IngestRequest


def main() -> None:
    if get_bool_env("FAQ_MONTHLY_RUN_INGEST", False):
        ingest_response = ingest(
            limit=None,
            since_days=365,
            workspace_id=None,
            agent_id=None,
            dry_run=False,
            source=FAQ_INGEST_SOURCE,
        )
        print("Monthly raw ingestion finished.")
        print(f"source={ingest_response.source}")
        print(f"records_written={ingest_response.records_written}")

    request = IngestRequest(
        limit=None,
        since_days=365,
        workspace_id=None,
        agent_id=None,
    )

    summary = run_suggestion_pipeline(request)

    print("Monthly FAQ pipeline finished.")
    print(f"run_id={summary.run_id}")
    print(f"company_count={summary.company_count}")
    print(f"suggestions={summary.cluster_count}")
    print(f"examples={summary.total_examples}")


if __name__ == "__main__":
    main()
