﻿"""Legacy compatibility facade for `app.api.suggestion_service`."""

import sys as _sys

from app.api.suggestion_service import *  # noqa: F401,F403
import app.api.suggestion_service as _impl

_sys.modules[__name__] = _impl
