﻿"""Legacy compatibility facade for `app.api.validation_service`."""

import sys as _sys

from app.api.validation_service import *  # noqa: F401,F403
import app.api.validation_service as _impl

_sys.modules[__name__] = _impl
