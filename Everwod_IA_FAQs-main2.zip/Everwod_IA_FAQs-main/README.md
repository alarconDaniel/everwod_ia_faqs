# Everwod FAQ Intelligence

Prototipo backend/frontend para detectar patrones conversacionales recurrentes en chats historicos de Everwod y convertirlos en sugerencias de FAQs validadas por una persona.

El sistema trabaja sobre el modelo limpio `faq_mvp` definido en `../sql/` y evita depender de APIs pagas. Los embeddings usan un modelo local liviano de `sentence-transformers` o un fallback hash local. La generacion con Qwen local produce la FAQ completa en JSON estructurado: decision de publicacion, pregunta canonica, respuesta canonica, confianza y razon.

## Arquitectura

- `ingest_service.py` lee mensajes normalizados desde `faq_mvp.messages`, los une con `faq_mvp.conversations` y `faq_mvp.workspaces`, y empareja ultimo mensaje de usuario con la siguiente respuesta del asistente.
- `suggestion_service.py` ejecuta embeddings, clustering, deduplicacion contra `faq_mvp.existing_faqs`, sintesis completa con Qwen, validadores de calidad y persistencia en `pipeline_runs`, `pipeline_metrics`, `question_clusters`, `faq_candidates`, `faq_candidate_examples` y `message_embeddings`.
- `validation_service.py` lista candidatos desde PostgreSQL, registra eventos en `faq_validation_events` y, al aprobar, promueve la sugerencia a `faq_mvp.existing_faqs`.
- `scheduler.py` ejecuta el flujo persistente de sugerencias cada 7 dias por defecto.
- `frontend/` contiene el panel React/Vite para generar sugerencias, revisar candidatos y consultar historial de validaciones.

## Preparar la base de datos

Desde la carpeta raiz del proyecto padre:

```bash
psql -U postgres -d everwod_faq_mvp -f sql/01_create_schemas.sql
psql -U postgres -d everwod_faq_mvp -f pgdump_production_08-04-2026-22-02-09.sql
psql -U postgres -d everwod_faq_mvp -f sql/03_load_or_restore_raw_instructions.sql
psql -U postgres -d everwod_faq_mvp -f sql/02_create_tables.sql
psql -U postgres -d everwod_faq_mvp -f sql/04_transform_raw_to_faq_mvp.sql
psql -U postgres -d everwod_faq_mvp -f sql/05_validation_queries.sql
```

No es necesario procesar el dump desde Python. El backend consume el resultado normalizado en `faq_mvp`.

## Configuracion

```bash
cp .env.example .env
```

Variables principales:

```env
DB_NAME=everwod_faq_mvp
DB_USER=postgres
DB_PASSWORD=postgres
DB_HOST=localhost
DB_PORT=5432
FAQ_SCHEMA=faq_mvp

CORS_ALLOW_ORIGINS=http://localhost:5173,http://127.0.0.1:5173

FAQ_EMBEDDING_BACKEND=sentence-transformers
FAQ_EMBEDDING_MODEL=all-MiniLM-L6-v2
FAQ_LLM_ENABLED=true
FAQ_LLM_MODEL=Qwen/Qwen2.5-0.5B-Instruct

FAQ_CLUSTER_EPS=0.34
FAQ_MIN_CLUSTER_SIZE=3
FAQ_MIN_CLUSTER_COHESION=0.72
FAQ_MIN_GENERATION_CONFIDENCE=0.70
FAQ_SKIP_EXISTING=true
FAQ_DUPLICATE_THRESHOLD=0.78

FAQ_SCHEDULE_INTERVAL_DAYS=7
```

Para entornos sin modelo descargado, se puede usar `FAQ_EMBEDDING_BACKEND=hash`. Si Qwen no carga o devuelve JSON invalido, el pipeline descarta el cluster en vez de publicar una respuesta historica cruda.

## Instalacion backend

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python test_connection.py
```

En Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python test_connection.py
```

## Levantar servicios

```bash
uvicorn ingest_service:app --reload --port 8001
uvicorn suggestion_service:app --reload --port 8003
uvicorn validation_service:app --reload --port 8004
```

El servicio de embeddings independiente sigue disponible si se necesita:

```bash
uvicorn embed_service:app --reload --port 8002
```

## Frontend

```bash
cd frontend
cp .env.example .env
npm ci
npm run dev
```

Abrir `http://localhost:5173`.

## Flujo manual

1. Ingesta:

   ```bash
   curl -X POST http://127.0.0.1:8001/ingest \
     -H "Content-Type: application/json" \
     -d '{"limit":15000,"since_days":90}'
   ```

2. Generar y persistir sugerencias:

   ```bash
   curl -X POST http://127.0.0.1:8003/suggest \
     -H "Content-Type: application/json" \
     -d '{"limit":15000,"since_days":90}'
   ```

3. Consultar candidatos de la ultima corrida exitosa:

   ```bash
   curl "http://127.0.0.1:8003/suggestions?status=pending"
   ```

   Para inspeccionar todo el historial de candidatos:

   ```bash
   curl "http://127.0.0.1:8003/suggestions?include_all=true"
   ```

4. Validar:

   ```bash
   curl -X POST http://127.0.0.1:8004/validate \
     -H "Content-Type: application/json" \
     -d '{"suggestion_id":"UUID","reviewer":"Nombre","status":"approved","notes":"Valida"}'
   ```

Cuando el estado es `approved`, el candidato se inserta o actualiza como FAQ persistente en `faq_mvp.existing_faqs`. Si el candidato no tiene `agent_id` o no tiene respuesta sugerida, la aprobacion devuelve error `409` y no escribe una FAQ incompleta.

## Scheduler semanal

```bash
python scheduler.py
```

Por defecto ejecuta inmediatamente y luego cada 7 dias. Ajustar con:

```env
FAQ_SCHEDULE_INTERVAL_DAYS=7
FAQ_SCHEDULE_LIMIT=15000
FAQ_SCHEDULE_SINCE_DAYS=90
```

## Pruebas

```bash
pytest
python -m py_compile faq_common.py faq_models.py ingest_service.py suggestion_service.py validation_service.py scheduler.py
cd frontend && npm run build
```

Las pruebas mockean PostgreSQL/modelos pesados y cubren emparejamiento, filtros, deduplicacion, limpieza de PII, parsing JSON de Qwen, rechazo de respuestas conversacionales, fallback sin LLM, clusters incoherentes, pregunta canonica, validacion, promocion a FAQ y endpoints basicos.

## Docker

```bash
cp .env.example .env
docker compose up --build
```

El contenedor de PostgreSQL queda vacio hasta restaurar el dump y ejecutar los scripts SQL. El volumen `../sql:/sql:ro` se monta para facilitar esa carga.

## Metricas guardadas

Cada corrida registra:

- conversaciones analizadas;
- mensajes candidatos a FAQ;
- candidatos generados o actualizados;
- clusters validos;
- tamano promedio de cluster;
- duplicados omitidos;
- workspaces procesados;
- embeddings persistidos;
- clusters rechazados por baja calidad, LLM o validadores;
- silhouette score cuando aplica.

## Decisiones tecnicas

- `company_id` se conserva como alias de `workspace_id` para compatibilidad con el frontend y la API previa.
- `faq_mvp.existing_faqs` contiene FAQs heredadas y FAQs promovidas desde candidatos aprobados; esto mantiene una sola tabla de FAQs activas para deduplicacion futura.
- `message_embeddings.embedding` usa `double precision[]` para no requerir `pgvector` en el prototipo academico.
- Qwen local genera la FAQ completa, no solo la respuesta. El formato obligatorio es JSON con `publish`, `canonical_question`, `canonical_answer`, `confidence` y `reason`.
- El fallback sin Qwen es conservador: no publica candidatos para evitar reciclar texto conversacional del dump.
- `GET /suggestions` muestra por defecto la ultima corrida exitosa para que el frontend no mezcle candidatos malos antiguos con resultados nuevos.

## Limitaciones

- La calidad del clustering depende del volumen de mensajes por workspace y del umbral `FAQ_CLUSTER_EPS`.
- El fallback hash de embeddings es economico y reproducible, pero menos semantico que `all-MiniLM-L6-v2`.
- La promocion a FAQ requiere `agent_id`; las conversaciones sin agente inferido deben resolverse con una regla de negocio antes de aprobarse.
- El prototipo registra metricas tecnicas; una evaluacion experimental formal de precision/resolucion debe hacerse con una muestra revisada por humanos.
