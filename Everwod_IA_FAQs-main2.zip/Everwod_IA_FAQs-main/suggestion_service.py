import hashlib
import json
import os
import re
import uuid
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple

from fastapi import FastAPI, HTTPException
from psycopg2.extras import Json, RealDictCursor

from faq_common import (
    DATA_DIR,
    FAQ_SCHEMA,
    configure_cors,
    fold_text,
    get_bool_env,
    get_db_connection,
    get_float_env,
    get_int_env,
    load_json,
    load_json_lines,
    normalize_question,
    normalize_text,
    save_json,
)
from faq_models import IngestRequest, SuggestionResponse, SuggestionSummary
from ingest_service import fetch_conversation_records


app = FastAPI(title="Everwod FAQ Suggestion Service")
configure_cors(app)

MODEL_NAME = os.getenv("FAQ_EMBEDDING_MODEL", "all-MiniLM-L6-v2")
FAQ_EMBEDDING_BACKEND = os.getenv("FAQ_EMBEDDING_BACKEND", "sentence-transformers")
FAQ_LLM_MODEL = os.getenv("FAQ_LLM_MODEL", "Qwen/Qwen2.5-0.5B-Instruct")
FAQ_LLM_ENABLED = get_bool_env("FAQ_LLM_ENABLED", False)
FAQ_CLUSTER_EPS = get_float_env("FAQ_CLUSTER_EPS", 0.34)
FAQ_MIN_CLUSTER_SIZE = get_int_env("FAQ_MIN_CLUSTER_SIZE", 3)
FAQ_SKIP_EXISTING = get_bool_env("FAQ_SKIP_EXISTING", True)
FAQ_DUPLICATE_THRESHOLD = get_float_env("FAQ_DUPLICATE_THRESHOLD", 0.78)
FAQ_MIN_CLUSTER_SUPPORT = get_float_env("FAQ_MIN_CLUSTER_SUPPORT", 0.68)
FAQ_MIN_CLUSTER_COHESION = get_float_env("FAQ_MIN_CLUSTER_COHESION", 0.72)
FAQ_MIN_GENERATION_CONFIDENCE = get_float_env("FAQ_MIN_GENERATION_CONFIDENCE", 0.70)
FAQ_HASH_EMBEDDING_DIM = get_int_env("FAQ_HASH_EMBEDDING_DIM", 96)

SUGGESTIONS_PATH = DATA_DIR / "faq_suggestions.json"
CONVERSATIONS_PATH = DATA_DIR / "conversations.jsonl"

EMBEDDING_MODEL: Optional[Any] = None
ANSWER_GENERATOR: Optional[Any] = None
MODELS_READY = False
EMBEDDING_BACKEND_READY = "hash"


def load_models() -> None:
    global EMBEDDING_MODEL, ANSWER_GENERATOR, MODELS_READY, EMBEDDING_BACKEND_READY
    if MODELS_READY:
        return

    if FAQ_EMBEDDING_BACKEND != "hash":
        try:
            from sentence_transformers import SentenceTransformer

            EMBEDDING_MODEL = SentenceTransformer(MODEL_NAME)
            EMBEDDING_BACKEND_READY = MODEL_NAME
        except Exception as exc:
            print(f"No se pudo cargar {MODEL_NAME}. Se usara embedding hash local. Error: {exc}")
            EMBEDDING_MODEL = None
            EMBEDDING_BACKEND_READY = "hash"

    if FAQ_LLM_ENABLED:
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline

            tokenizer = AutoTokenizer.from_pretrained(FAQ_LLM_MODEL)
            model = AutoModelForCausalLM.from_pretrained(FAQ_LLM_MODEL)
            ANSWER_GENERATOR = pipeline("text-generation", model=model, tokenizer=tokenizer)
        except Exception as exc:
            print(f"No se pudo cargar {FAQ_LLM_MODEL}. Se usara fallback historico. Error: {exc}")
            ANSWER_GENERATOR = None

    MODELS_READY = True


def _as_vector(raw: Any) -> List[float]:
    if hasattr(raw, "tolist"):
        raw = raw.tolist()
    return [float(value) for value in raw]


def _normalize_vector(vector: List[float]) -> List[float]:
    norm = sum(value * value for value in vector) ** 0.5
    if norm <= 0:
        return vector
    return [value / norm for value in vector]


def _dot(left: List[float], right: List[float]) -> float:
    return sum(a * b for a, b in zip(left, right))


def _mean_vector(vectors: List[List[float]]) -> List[float]:
    size = len(vectors[0])
    return [sum(vector[index] for vector in vectors) / len(vectors) for index in range(size)]


def _hash_embedding(text: str, dimension: int = FAQ_HASH_EMBEDDING_DIM) -> List[float]:
    vector = [0.0] * dimension
    for token in re.findall(r"\w+", fold_text(text)):
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        index = int.from_bytes(digest[:4], "big") % dimension
        sign = 1.0 if digest[4] % 2 == 0 else -1.0
        vector[index] += sign
    return _normalize_vector(vector)


def encode_texts(texts: List[str]) -> List[List[float]]:
    load_models()
    clean_texts = [normalize_text(text) for text in texts]
    if EMBEDDING_MODEL is None:
        return [_hash_embedding(text) for text in clean_texts]

    raw_embeddings = EMBEDDING_MODEL.encode(
        clean_texts,
        convert_to_numpy=False,
        normalize_embeddings=True,
        show_progress_bar=False,
    )
    return [_normalize_vector(_as_vector(embedding)) for embedding in raw_embeddings]


def _fallback_dbscan(embeddings: List[List[float]]) -> List[int]:
    labels = [-1] * len(embeddings)
    cluster_id = 0
    visited = set()
    min_similarity = 1.0 - FAQ_CLUSTER_EPS

    for index, embedding in enumerate(embeddings):
        if index in visited:
            continue
        neighbors = [idx for idx, other in enumerate(embeddings) if _dot(embedding, other) >= min_similarity]
        visited.add(index)
        if len(neighbors) < FAQ_MIN_CLUSTER_SIZE:
            continue
        queue = list(neighbors)
        labels[index] = cluster_id
        while queue:
            neighbor = queue.pop()
            if neighbor not in visited:
                visited.add(neighbor)
                expanded = [
                    idx
                    for idx, other in enumerate(embeddings)
                    if _dot(embeddings[neighbor], other) >= min_similarity
                ]
                if len(expanded) >= FAQ_MIN_CLUSTER_SIZE:
                    queue.extend(idx for idx in expanded if idx not in queue)
            if labels[neighbor] == -1:
                labels[neighbor] = cluster_id
        cluster_id += 1

    return labels


def cluster_embeddings(embeddings: List[List[float]]) -> List[int]:
    try:
        from sklearn.cluster import DBSCAN

        model = DBSCAN(eps=FAQ_CLUSTER_EPS, min_samples=FAQ_MIN_CLUSTER_SIZE, metric="cosine")
        return [int(label) for label in model.fit_predict(embeddings)]
    except Exception:
        return _fallback_dbscan(embeddings)


def compute_silhouette(embeddings: List[List[float]], labels: List[int]) -> Optional[float]:
    clean_pairs = [(embedding, label) for embedding, label in zip(embeddings, labels) if label != -1]
    clean_labels = [label for _, label in clean_pairs]
    if len(set(clean_labels)) <= 1 or len(clean_pairs) <= len(set(clean_labels)):
        return None
    try:
        from sklearn.metrics import silhouette_score

        return round(float(silhouette_score([item[0] for item in clean_pairs], clean_labels, metric="cosine")), 4)
    except Exception:
        return None


def parse_datetime(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).replace(tzinfo=None)
    except ValueError:
        return None


EMOJI_PATTERN = re.compile(
    "["
    "\U0001F300-\U0001FAFF"
    "\U00002700-\U000027BF"
    "\U00002600-\U000026FF"
    "]",
    flags=re.UNICODE,
)

TIME_PATTERN = re.compile(
    r"\b(?:[01]?\d|2[0-3])(?:[:.]\d{2})?\s*(?:a\.?\s*m\.?|p\.?\s*m\.?|am|pm)\b|\b(?:[01]?\d|2[0-3])[:.]\d{2}\b",
    flags=re.IGNORECASE,
)
DATE_PATTERN = re.compile(r"\b\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?\b")
PLACEHOLDER_PATTERN = re.compile(r"\[(?:telefono|tel[eé]fono|correo|email|persona|personas)\]", flags=re.IGNORECASE)
RAW_URL_PATTERN = re.compile(r"https?://|www\.", flags=re.IGNORECASE)


def has_emoji(text: str) -> bool:
    return bool(EMOJI_PATTERN.search(text or ""))


def is_internal_tool_trace(text: str) -> bool:
    folded = fold_text(text)
    return any(
        fragment in folded
        for fragment in (
            "reasoning",
            "function_call",
            "function call",
            "tool_call",
            "tool call",
            "getschedules",
            "get schedules",
            "assistant to=functions",
            "arguments",
        )
    )


def is_low_quality_chat_style(text: str) -> bool:
    folded = fold_text(text)
    if has_emoji(text):
        return True
    chat_fragments = (
        "tu toxica de confianza",
        "mi team humano",
        "te paso",
        "te envio",
        "te comparto",
        "me compartes",
        "me puedes compartir",
        "enviame",
        "envianos",
        "mandame",
        "me mandas",
        "indicanos",
        "escribenos",
        "te gustaria",
        "aqui tienes",
        "para que ciudad",
        "que ciudad",
        "mi nombre es",
        "estoy aqui para ayudarte",
        "estoy para ayudarte",
        "dejartelo confirmado",
        "dejarte confirmado",
        "soporte de pago",
        "soporte para dejar",
        "porfa",
        "por favor escribenos",
        "gracias por escribir",
        "feliz dia",
        "bendiciones",
    )
    if any(fragment in folded for fragment in chat_fragments):
        return True
    if re.search(r"(?i)^(hola|buenos dias|buenas tardes|buenas noches|cordial saludo)\b", normalize_text(text)):
        return True
    return False


def has_case_specific_time_reference(text: str) -> bool:
    folded = fold_text(text)
    temporal_words = (
        "hoy",
        "manana",
        "ayer",
        "pasado manana",
        "esta tarde",
        "esta noche",
        "este jueves",
        "este viernes",
        "lunes",
        "martes",
        "miercoles",
        "jueves",
        "viernes",
        "sabado",
        "domingo",
    )
    return bool(TIME_PATTERN.search(text) or DATE_PATTERN.search(text) or any(word in folded for word in temporal_words))


def clean_question_evidence(text: str) -> str:
    clean = redact_personal_data(text)
    clean = re.sub(r"(?i)\b(hola|buenos dias|buenos d[ií]as|buenas tardes|buenas noches|gracias)\b[,!¡\s.-]*", "", clean)
    clean = re.sub(r"\b(?:hoy|mañana|manana|ayer|lunes|martes|miercoles|miércoles|jueves|viernes|sabado|sábado|domingo)\b", "", clean, flags=re.IGNORECASE)
    clean = TIME_PATTERN.sub("", clean)
    clean = DATE_PATTERN.sub("", clean)
    clean = normalize_text(clean.strip(" -:;,."))
    return clean


def clean_answer_evidence(text: str, company_name: Optional[str] = None) -> str:
    if is_internal_tool_trace(text):
        return ""
    clean = clean_faq_answer(text, company_name=company_name)
    clean = PLACEHOLDER_PATTERN.sub("", clean)
    clean = normalize_text(clean)
    return clean


def is_answer_evidence_usable(text: str) -> bool:
    clean = normalize_text(text)
    if len(clean) < 30:
        return False
    if is_internal_tool_trace(clean) or is_low_quality_chat_style(clean):
        return False
    if PLACEHOLDER_PATTERN.search(clean):
        return False
    return True


def is_valid_canonical_question(question: str) -> bool:
    clean = normalize_text(question)
    folded = fold_text(clean)
    if not 12 <= len(clean) <= 180:
        return False
    if is_internal_tool_trace(clean) or is_low_quality_chat_style(clean):
        return False
    if PLACEHOLDER_PATTERN.search(clean) or has_case_specific_time_reference(clean):
        return False
    if "gracias" in folded or folded.startswith(("hola", "buenas")):
        return False
    if any(fragment in folded for fragment in ("lo del", "y de una", "de que tienes", "quisiera", "me gustaria", "quiero ")):
        return False
    if re.search(r"\b(tienes|tengo|gustaria|quiero|quisiera)\b", folded):
        return False
    canonical_starts = (
        "como ",
        "cual ",
        "cuales ",
        "cuanto ",
        "donde ",
        "cuando ",
        "es posible ",
        "se puede ",
        "que opciones ",
        "que metodos ",
        "el negocio ",
        "la reserva ",
        "las clases ",
    )
    folded_without_marks = folded.strip("¿? ")
    if not folded_without_marks.startswith(canonical_starts):
        return False
    if re.search(r"\b\d{3,}\b", clean):
        return False
    if "?" not in clean:
        return False
    if len(clean.split()) < 4:
        return False
    return True


def is_valid_canonical_answer(answer: str) -> bool:
    clean = normalize_text(answer)
    folded = fold_text(clean)
    if not 60 <= len(clean) <= 650:
        return False
    if is_internal_tool_trace(clean) or is_low_quality_chat_style(clean):
        return False
    if PLACEHOLDER_PATTERN.search(clean) or has_emoji(clean):
        return False
    if RAW_URL_PATTERN.search(clean):
        return False
    if has_case_specific_time_reference(clean):
        return False
    if "?" in clean:
        return False
    forbidden_fragments = (
        "tu toxica de confianza",
        "envia",
        "envie",
        "compart",
        "whatsapp para obtener mas informacion",
        "atencion al cliente para obtener mas informacion",
        "mi nombre es",
        "aqui tienes",
    )
    if any(fragment in folded for fragment in forbidden_fragments):
        return False
    if folded.startswith(("si,", "si ", "claro", "aqui")):
        return False
    if re.search(r"\b(te|tu|tus|me|mi|tienes|tengo|quieres|quiero|gustaria)\b", folded):
        return False
    return True


def fallback_unpublishable(reason: str, confidence: float = 0.0) -> Dict[str, Any]:
    return {
        "publish": False,
        "canonical_question": "",
        "canonical_answer": "",
        "confidence": max(0.0, min(1.0, confidence)),
        "reason": reason,
        "mode": "conservative_fallback",
    }


def redact_personal_data(text: str, protected_terms: Optional[List[str]] = None) -> str:
    text = normalize_text(text)
    if not text:
        return ""

    protected_values: Dict[str, str] = {}
    for index, term in enumerate(protected_terms or []):
        clean_term = normalize_text(term)
        if clean_term:
            token = f"__PROTECTED_{index}__"
            protected_values[token] = clean_term
            text = re.sub(re.escape(clean_term), token, text, flags=re.IGNORECASE)

    name_word = r"[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}"
    text = re.sub(r"[\w.+-]+@[\w-]+\.[\w.-]+", "[correo]", text)
    text = re.sub(r"\b(?:\+?\d[\s().-]?){7,}\b", "[telefono]", text)
    text = re.sub(rf"(?i)\b(hola|buenos dias|buenos días|buenas tardes|buenas noches),?\s+{name_word}(?:\s+{name_word}){{0,3}}", r"\1", text)
    text = re.sub(rf"(?i)\b(gracias por escribir(?:nos)?),?\s+{name_word}(?:\s+{name_word}){{0,3}}", r"\1", text)
    text = re.sub(rf"\b{name_word}(?:\s+{name_word})+\b", "[persona]", text)
    text = re.sub(r"\s+([,.;:])", r"\1", text)

    for token, value in protected_values.items():
        text = text.replace(token, value)
    return normalize_text(text)


def clean_faq_answer(answer: str, company_name: Optional[str] = None) -> str:
    protected_terms = [company_name] if company_name else []
    text = redact_personal_data(answer, protected_terms=protected_terms)
    if not text:
        return ""

    text = re.sub(r"(?is)^.*?(respuesta final|faq)\s*:\s*", "", text).strip()
    text = re.sub(r"(?i)^(hola|buenos dias|buenos días|buenas tardes|buenas noches|cordial saludo)[,!¡\s:.-]*", "", text)
    text = re.sub(r"(?i)\bgracias por escribir(?:nos)?[,!¡\s:.-]*", "", text)
    text = re.sub(r"(?i)\b(te ayudamos|te podemos ayudar|podemos ayudarte)\b", "el equipo puede orientar", text)
    text = re.sub(r"(?i)\bte enviaremos\b", "se enviara", text)
    text = re.sub(r"(?i)\bte confirmamos\b", "se confirma", text)
    text = re.sub(r"(?i)\bte recomendamos\b", "se recomienda", text)
    text = re.sub(r"(?i)\b(envianos|envíanos|indicanos|indícanos|escribenos|escríbenos)\b", "se debe informar", text)
    text = re.sub(r"(?i)\btu\s+(dia|día|reserva|clase|plan|pago|inscripcion|inscripción|membresia|membresía)\b", r"el \1", text)
    text = re.sub(r"(?i)\btus\s+(datos|reservas|clases|pagos)\b", r"los \1", text)
    text = re.sub(r"\[persona\],?\s*", "", text)
    text = normalize_text(text.strip(" -:;,."))
    if not text:
        return ""
    text = text[0].upper() + text[1:]
    if text[-1] not in ".!?":
        text += "."
    return text


def is_good_faq_candidate(text: str) -> bool:
    text = normalize_text(text)
    folded = fold_text(text).strip(" ¿?¡!.,;:")
    word_count = len(text.split())

    if len(text) < 12 or word_count < 3 or len(text) > 280:
        return False
    if re.search(r"[\w.+-]+@[\w-]+\.[\w.-]+", text):
        return False
    if re.search(r"\b\d(?:[\s().-]?\d){6,}\b", text):
        return False

    trivial = {"hola", "buenas", "buenos dias", "buenas tardes", "buenas noches", "si", "no", "ok", "dale", "gracias"}
    if folded in trivial:
        return False

    non_faq_fragments = (
        "quien soy",
        "que hora",
        "que rol",
        "hora es actualmente",
        "que usuarios",
        "usuarios agendaron",
        "usuarios estaran",
        "personas asistiran",
        "quien asist",
    )
    if any(fragment in folded for fragment in non_faq_fragments):
        return False
    if "gracias" in folded and word_count <= 7 and "?" not in text:
        return False

    question_prefixes = (
        "como ",
        "cuanto ",
        "donde ",
        "cuando ",
        "puedo ",
        "quiero ",
        "quisiera ",
        "necesito ",
        "tienen ",
        "me ayudas ",
        "me puedes ",
        "me puede ",
        "me gustaria ",
        "seria posible ",
    )
    intent_keywords = (
        "precio",
        "precios",
        "plan",
        "planes",
        "mensualidad",
        "horario",
        "horarios",
        "ubicacion",
        "direccion",
        "reservar",
        "reserva",
        "agendar",
        "clase",
        "pagar",
        "pago",
        "qr",
        "crossfit",
        "informacion",
        "cortesia",
        "membresia",
        "inscripcion",
    )
    has_question_signal = "?" in text or any(folded.startswith(prefix) for prefix in question_prefixes)
    has_business_intent = any(keyword in folded for keyword in intent_keywords)
    return has_question_signal and has_business_intent


def company_key(item: Dict[str, Any]) -> str:
    return normalize_text(str(item.get("company_id") or item.get("workspace_id") or "unknown"))


def most_common_answer(answers: List[str], protected_terms: Optional[List[str]] = None) -> str:
    clean_answers = []
    for answer in answers:
        clean = clean_faq_answer(redact_personal_data(answer, protected_terms=protected_terms))
        if clean and len(clean) >= 25:
            clean_answers.append(clean)
    if clean_answers:
        return Counter(clean_answers).most_common(1)[0][0]
    return "La informacion disponible no es suficiente para publicar una respuesta definitiva; se debe confirmar el procedimiento con el equipo responsable."


def clean_canonical_question(question: str) -> str:
    clean = clean_question_evidence(question)
    folded = fold_text(clean).strip(" ?")
    replacements = [
        (r"^(quisiera|quiero|necesito)\s+agendar\s+", "¿Cómo puedo agendar "),
        (r"^(quisiera|quiero|necesito)\s+reservar\s+", "¿Cómo puedo reservar "),
        (r"^(puedo|se puede)\s+pagar\s+con\s+la\s+mitad\b.*", "¿Es posible reservar pagando un anticipo?"),
        (r"^(como|cómo)\s+hago\s+para\s+pagar\s+por\s+", "¿Cómo puedo pagar por "),
        (r"^y?\s*(que|qué)\s+precio\s+tiene\s+el\s+", "¿Cuánto cuesta el "),
        (r"^cuanto\s+(vale|cuesta)\s+el\s+", "¿Cuánto cuesta el "),
    ]
    for pattern, replacement in replacements:
        if re.search(pattern, folded, flags=re.IGNORECASE):
            clean = re.sub(pattern, replacement, clean, flags=re.IGNORECASE)
            break
    clean = normalize_text(clean.strip(" -:;,.¿?"))
    if not clean:
        return ""
    if not clean.startswith("¿"):
        clean = f"¿{clean[0].upper()}{clean[1:]}"
    if not clean.endswith("?"):
        clean = f"{clean}?"
    return clean


def extract_json_object(raw_text: str) -> Optional[Dict[str, Any]]:
    text = normalize_text(raw_text)
    if not text:
        return None
    try:
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None
    try:
        parsed = json.loads(text[start : end + 1])
        return parsed if isinstance(parsed, dict) else None
    except json.JSONDecodeError:
        return None


def parse_llm_faq_candidate(raw_text: str) -> Optional[Dict[str, Any]]:
    payload = extract_json_object(raw_text)
    if payload is None:
        print("Qwen devolvio JSON invalido o ausente.")
        return None

    required = {"publish", "canonical_question", "canonical_answer", "confidence", "reason"}
    if not required.issubset(payload):
        print(f"Qwen devolvio JSON sin claves requeridas: {sorted(payload.keys())}")
        return None
    if not isinstance(payload["publish"], bool):
        print("Qwen devolvio publish con tipo invalido.")
        return None
    if not isinstance(payload["canonical_question"], str) or not isinstance(payload["canonical_answer"], str):
        print("Qwen devolvio pregunta/respuesta con tipo invalido.")
        return None
    if not isinstance(payload["reason"], str):
        print("Qwen devolvio reason con tipo invalido.")
        return None
    try:
        confidence = float(payload["confidence"])
    except (TypeError, ValueError):
        print("Qwen devolvio confidence no numerico.")
        return None
    if not 0 <= confidence <= 1:
        print(f"Qwen devolvio confidence fuera de rango: {confidence}")
        return None

    return {
        "publish": payload["publish"],
        "canonical_question": clean_canonical_question(payload["canonical_question"]),
        "canonical_answer": clean_faq_answer(payload["canonical_answer"]),
        "confidence": confidence,
        "reason": normalize_text(payload["reason"]),
        "mode": "llm_json",
    }


def validate_generated_candidate(candidate: Dict[str, Any]) -> Tuple[bool, str]:
    if not candidate.get("publish"):
        return False, "llm_publish_false"
    if float(candidate.get("confidence") or 0) < FAQ_MIN_GENERATION_CONFIDENCE:
        return False, "generation_confidence_below_threshold"
    if not is_valid_canonical_question(candidate.get("canonical_question", "")):
        return False, "invalid_canonical_question"
    if not is_valid_canonical_answer(candidate.get("canonical_answer", "")):
        return False, "invalid_canonical_answer"
    return True, ""


def generate_faq_candidate_with_llm(
    company_name: Optional[str],
    questions: List[str],
    historical_answers: List[str],
    cluster_metrics: Dict[str, Any],
    recurrence: int,
) -> Dict[str, Any]:
    clean_questions = [clean_question_evidence(question) for question in questions]
    clean_questions = [question for question in clean_questions if question and is_good_faq_candidate(question)]

    clean_answers = [clean_answer_evidence(answer, company_name=company_name) for answer in historical_answers]
    clean_answers = [answer for answer in clean_answers if is_answer_evidence_usable(answer)]

    if not ANSWER_GENERATOR:
        return fallback_unpublishable("LLM local no disponible; fallback conservador no publica candidatos.", 0.0)
    if len(clean_questions) < FAQ_MIN_CLUSTER_SIZE:
        return fallback_unpublishable("Evidencia insuficiente de preguntas utiles en el cluster.", 0.2)
    if len(clean_answers) < 1:
        return fallback_unpublishable("No hay respuestas historicas limpias suficientes para respaldar una FAQ.", 0.2)

    question_context = "\n".join(f"- {question}" for question in clean_questions[:8])
    answer_context = "\n".join(f"- {answer}" for answer in clean_answers[:6])

    messages = [
        {
            "role": "system",
            "content": (
                "Eres un normalizador de conocimiento empresarial, no un chatbot. "
                "Analiza patrones repetidos y sintetiza una FAQ reutilizable para futuros clientes. "
                "No copies textualmente mensajes ni respuestas historicas. Convierte variaciones concretas en formulaciones generales. "
                "No uses saludos, nombres, emojis, tono conversacional, preguntas de seguimiento, 'te', 'tu', 'me envias', 'te paso' ni frases casuales de marca. "
                "No uses fechas, horas, referencias temporales, placeholders como [telefono] o [correo], ni trazas internas como Reasoning, function_call, getSchedules o tool_call. "
                "Si la evidencia es contradictoria, mezcla temas o no permite una respuesta confiable, devuelve publish=false. "
                "Responde SOLO JSON valido, sin markdown ni texto adicional, con claves exactas: publish, canonical_question, canonical_answer, confidence, reason."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Empresa/workspace: {company_name or 'N/D'}\n"
                f"Recurrencia: {recurrence}\n"
                f"Metricas del cluster: {json.dumps(cluster_metrics, ensure_ascii=False)}\n\n"
                f"Preguntas reales limpias:\n{question_context}\n\n"
                f"Respuestas historicas limpias:\n{answer_context}\n\n"
                "Devuelve JSON. publish=true solo si existe una unica intencion clara y una respuesta respaldada por la evidencia."
            ),
        },
    ]

    try:
        tokenizer = ANSWER_GENERATOR.tokenizer
        prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        generated = ANSWER_GENERATOR(
            prompt,
            max_new_tokens=260,
            do_sample=False,
            return_full_text=False,
            pad_token_id=tokenizer.eos_token_id,
        )
        parsed = parse_llm_faq_candidate(generated[0].get("generated_text", ""))
        if parsed is None:
            return fallback_unpublishable("Qwen devolvio JSON invalido.", 0.0)
        if not parsed["publish"]:
            print(f"Qwen descarto cluster: {parsed.get('reason')}")
        return parsed
    except Exception as exc:
        print(f"Qwen fallo durante la sintesis del candidato FAQ: {exc}")
        return fallback_unpublishable(f"Error de generacion LLM: {exc}", 0.0)


def load_existing_faqs_by_company() -> Dict[str, List[str]]:
    if not FAQ_SKIP_EXISTING:
        return {}

    query = f"""
        SELECT workspace_id, question
        FROM {FAQ_SCHEMA}.existing_faqs
        WHERE is_active = true
          AND deleted_at IS NULL
          AND question IS NOT NULL
          AND btrim(question) <> ''
    """

    faqs_by_company: Dict[str, List[str]] = defaultdict(list)
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query)
                for workspace_id, question in cursor.fetchall():
                    clean = normalize_text(question)
                    if clean:
                        faqs_by_company[str(workspace_id)].append(clean)
    except Exception as exc:
        print(f"No se pudieron cargar FAQs existentes. Se generaran sugerencias sin deduplicar. Error: {exc}")
    return faqs_by_company


def is_existing_faq(question: str, existing_questions: List[str]) -> bool:
    if not existing_questions:
        return False

    normalized = normalize_question(question)
    if normalized in {normalize_question(existing) for existing in existing_questions}:
        return True

    embeddings = encode_texts([question, *existing_questions])
    similarities = [_dot(existing_embedding, embeddings[0]) for existing_embedding in embeddings[1:]]
    return bool(similarities and max(similarities) >= FAQ_DUPLICATE_THRESHOLD)


def _most_common_agent_id(items: Iterable[Dict[str, Any]]) -> Optional[str]:
    values = [str(item["agent_id"]) for item in items if item.get("agent_id")]
    if not values:
        return None
    return Counter(values).most_common(1)[0][0]


def cluster_intent_categories(questions: List[str]) -> set[str]:
    categories: set[str] = set()
    for question in questions:
        folded = fold_text(question)
        if any(term in folded for term in ("agendar", "reservar", "clase", "cortesia", "prueba", "horario")):
            categories.add("scheduling")
        if any(term in folded for term in ("pagar", "pago", "nequi", "daviplata", "pse", "efecty", "anticipo", "mitad", "tarjeta")):
            categories.add("payment")
        if any(term in folded for term in ("envio", "domicilio", "transportadora", "entrega", "prioritario", "ciudad", "chia")):
            categories.add("shipping")
        if any(term in folded for term in ("desayuno", "sorpresa", "producto", "media", "medias", "tienen", "manejan")):
            categories.add("product_availability")
        if any(term in folded for term in ("precio", "cuanto", "vale", "cuesta", "costo")):
            categories.add("pricing")
    return categories


def is_mixed_intent_cluster(questions: List[str]) -> Tuple[bool, str]:
    categories = cluster_intent_categories(questions)
    primary_categories = categories - {"pricing"}
    if len(primary_categories) > 1:
        return True, f"Cluster mezcla intenciones: {', '.join(sorted(primary_categories))}."
    if "product_availability" in categories and "shipping" in categories:
        return True, "Cluster mezcla disponibilidad de producto con condiciones de envio."
    return False, ""


def calculate_cluster_score(
    recurrence: int,
    cluster_cohesion: float,
    generation_confidence: float,
    valid_question_count: int,
    valid_answer_count: int,
) -> float:
    recurrence_score = min(1.0, recurrence / 10)
    evidence_score = min(1.0, (valid_question_count + valid_answer_count) / max(1, recurrence * 2))
    score = (
        0.30 * cluster_cohesion
        + 0.40 * generation_confidence
        + 0.15 * recurrence_score
        + 0.15 * evidence_score
    )
    return round(max(0.0, min(100.0, score * 100)), 2)


def build_company_candidates(
    conversations: List[Dict[str, Any]],
    existing_questions: Optional[List[str]] = None,
    run_id: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    existing_questions = existing_questions or []
    valid_items = []
    for item in conversations:
        user_text = normalize_text(item.get("user_text"))
        if user_text and is_good_faq_candidate(user_text):
            valid_items.append({**item, "user_text": user_text})

    stats = {
        "valid_examples": len(valid_items),
        "duplicates_omitted": 0,
        "clusters_valid": 0,
        "clusters_rejected": 0,
        "llm_rejected": 0,
        "validator_rejected": 0,
        "silhouette_score": None,
    }
    if len(valid_items) < FAQ_MIN_CLUSTER_SIZE:
        return [], stats

    user_texts = [item["user_text"] for item in valid_items]
    embeddings = encode_texts(user_texts)
    labels = cluster_embeddings(embeddings)
    stats["silhouette_score"] = compute_silhouette(embeddings, labels)

    cluster_groups: Dict[int, List[int]] = defaultdict(list)
    for index, label in enumerate(labels):
        if label != -1:
            cluster_groups[int(label)].append(index)

    candidates: List[Dict[str, Any]] = []
    for label, indices in cluster_groups.items():
        center = _normalize_vector(_mean_vector([embeddings[index] for index in indices]))
        support_values = [_dot(embeddings[index], center) for index in indices]
        support = round(sum(support_values) / len(support_values), 4)
        min_support = round(min(support_values), 4)
        cluster_cohesion = round((support + min_support) / 2, 4)
        if support < FAQ_MIN_CLUSTER_SUPPORT or cluster_cohesion < FAQ_MIN_CLUSTER_COHESION:
            stats["clusters_rejected"] += 1
            print(
                "Cluster descartado por baja cohesion: "
                f"support={support}, min_support={min_support}, cohesion={cluster_cohesion}"
            )
            continue

        best_index = max(indices, key=lambda idx: _dot(embeddings[idx], center))
        representative = valid_items[best_index]
        cluster_questions = [user_texts[index] for index in indices]
        mixed_cluster, mixed_reason = is_mixed_intent_cluster(cluster_questions)
        if mixed_cluster:
            stats["clusters_rejected"] += 1
            print(f"Cluster descartado por intenciones mezcladas: {mixed_reason}")
            continue

        examples: List[str] = []
        example_records: List[Dict[str, Any]] = []
        sorted_indices = sorted(indices, key=lambda item_index: _dot(embeddings[item_index], center), reverse=True)
        for idx in sorted_indices:
            example_text = clean_question_evidence(user_texts[idx])
            if example_text not in examples:
                examples.append(example_text)
            example_records.append(
                {
                    "message_pk": valid_items[idx].get("user_message_pk"),
                    "conversation_pk": valid_items[idx].get("conversation_pk"),
                    "original_user_message": example_text,
                    "assistant_response": clean_answer_evidence(
                        valid_items[idx].get("assistant_text", ""),
                        representative.get("company_name"),
                    ),
                    "similarity_score": round(float(_dot(embeddings[idx], center)), 6),
                    "embedding": embeddings[idx],
                }
            )

        answers = [normalize_text(valid_items[index].get("assistant_text")) for index in indices]
        clean_answer_count = sum(1 for answer in answers if is_answer_evidence_usable(clean_answer_evidence(answer, representative.get("company_name"))))
        generation = generate_faq_candidate_with_llm(
            company_name=representative.get("company_name"),
            questions=cluster_questions,
            historical_answers=answers,
            cluster_metrics={
                "cluster_label": label,
                "cluster_support": support,
                "min_support": min_support,
                "cluster_cohesion": cluster_cohesion,
                "valid_question_evidence_count": len(examples),
                "valid_answer_evidence_count": clean_answer_count,
            },
            recurrence=len(indices),
        )
        is_valid_generation, rejection_reason = validate_generated_candidate(generation)
        if not is_valid_generation:
            stats["clusters_rejected"] += 1
            if generation.get("publish") is False:
                stats["llm_rejected"] += 1
            else:
                stats["validator_rejected"] += 1
            print(
                "Cluster descartado despues de generacion: "
                f"{rejection_reason}; reason={generation.get('reason')}"
            )
            continue

        question_text = generation["canonical_question"]
        answer_text = generation["canonical_answer"]

        if is_existing_faq(question_text, existing_questions):
            stats["duplicates_omitted"] += 1
            continue

        first_seen = min((parse_datetime(valid_items[index].get("created_at")) for index in indices), default=None)
        last_seen = max((parse_datetime(valid_items[index].get("created_at")) for index in indices), default=None)
        workspace_id = representative.get("workspace_id")
        cluster_score = calculate_cluster_score(
            recurrence=len(indices),
            cluster_cohesion=cluster_cohesion,
            generation_confidence=float(generation["confidence"]),
            valid_question_count=len(examples),
            valid_answer_count=clean_answer_count,
        )

        candidates.append(
            {
                "candidate_id": str(uuid.uuid4()),
                "run_id": run_id,
                "workspace_id": int(workspace_id) if workspace_id is not None else None,
                "company_id": company_key(representative),
                "company_name": representative.get("company_name"),
                "agent_id": _most_common_agent_id(valid_items[index] for index in indices),
                "normalized_question": question_text,
                "suggested_answer": answer_text,
                "cluster_label": question_text[:120],
                "recurrence_count": len(indices),
                "first_seen_at": first_seen,
                "last_seen_at": last_seen,
                "cluster_id": None,
                "algorithm": "DBSCAN",
                "centroid_embedding": center,
                "cluster_size": len(indices),
                "support_examples": examples[:3],
                "cluster_score": cluster_score,
                "cluster_metadata": {
                    "label": label,
                    "support": support,
                    "min_support": min_support,
                    "cluster_cohesion": cluster_cohesion,
                    "eps": FAQ_CLUSTER_EPS,
                    "min_cluster_size": FAQ_MIN_CLUSTER_SIZE,
                    "embedding_backend": EMBEDDING_BACKEND_READY,
                    "intent_categories": sorted(cluster_intent_categories(cluster_questions)),
                },
                "candidate_metadata": {
                    "cluster_score": cluster_score,
                    "support": support,
                    "cluster_cohesion": cluster_cohesion,
                    "generation_confidence": generation["confidence"],
                    "generation_reason": generation["reason"],
                    "valid_answer_evidence_count": clean_answer_count,
                    "valid_question_evidence_count": len(examples),
                    "duplicate_threshold": FAQ_DUPLICATE_THRESHOLD,
                    "llm_model": FAQ_LLM_MODEL if ANSWER_GENERATOR else "unavailable",
                    "generation_mode": generation.get("mode", "unknown"),
                    "rejected_by_validator": None,
                    "run_id": run_id,
                },
                "examples": example_records[:10],
            }
        )
        stats["clusters_valid"] += 1

    return candidates, stats


def build_suggestion_candidates(
    conversations: List[Dict[str, Any]],
    existing_faqs_by_company: Optional[Dict[str, List[str]]] = None,
    run_id: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    conversations_by_company: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for item in conversations:
        conversations_by_company[company_key(item)].append(item)

    existing_faqs_by_company = existing_faqs_by_company or load_existing_faqs_by_company()
    all_candidates: List[Dict[str, Any]] = []
    silhouettes: List[float] = []
    total_valid = 0
    duplicates = 0
    valid_clusters = 0
    rejected_clusters = 0
    llm_rejected = 0
    validator_rejected = 0

    for company_id, items in conversations_by_company.items():
        candidates, stats = build_company_candidates(
            items,
            existing_questions=existing_faqs_by_company.get(company_id, []),
            run_id=run_id,
        )
        all_candidates.extend(candidates)
        total_valid += int(stats["valid_examples"])
        duplicates += int(stats["duplicates_omitted"])
        valid_clusters += int(stats["clusters_valid"])
        rejected_clusters += int(stats["clusters_rejected"])
        llm_rejected += int(stats["llm_rejected"])
        validator_rejected += int(stats["validator_rejected"])
        if stats["silhouette_score"] is not None:
            silhouettes.append(float(stats["silhouette_score"]))

    silhouette = round(sum(silhouettes) / len(silhouettes), 4) if silhouettes else None
    stats = {
        "company_count": len(conversations_by_company),
        "conversations_analyzed": len(conversations),
        "total_examples": total_valid,
        "clusters_valid": valid_clusters,
        "clusters_rejected": rejected_clusters,
        "llm_rejected": llm_rejected,
        "validator_rejected": validator_rejected,
        "duplicates_omitted": duplicates,
        "silhouette_score": silhouette,
        "average_cluster_size": round(total_valid / valid_clusters, 2) if valid_clusters else 0.0,
    }
    return all_candidates, stats


def _candidate_to_response(candidate: Dict[str, Any]) -> SuggestionResponse:
    return SuggestionResponse(
        id=str(candidate["candidate_id"]),
        company_id=str(candidate.get("company_id") or candidate.get("workspace_id")),
        company_name=candidate.get("company_name"),
        workspace_id=int(candidate["workspace_id"]),
        agent_id=str(candidate["agent_id"]) if candidate.get("agent_id") else None,
        question=candidate["normalized_question"],
        answer=candidate.get("suggested_answer") or "",
        cluster_size=int(candidate.get("recurrence_count") or candidate.get("cluster_size") or 0),
        support_examples=list(candidate.get("support_examples") or []),
        cluster_score=float(candidate.get("cluster_score") or 0.0),
        status=candidate.get("status", "pending"),
        created_at=candidate.get("created_at"),
        updated_at=candidate.get("updated_at"),
        run_id=candidate.get("run_id"),
    )


def build_suggestions(conversations: List[Dict[str, Any]]) -> SuggestionSummary:
    candidates, stats = build_suggestion_candidates(conversations)
    suggestions = [_candidate_to_response(candidate) for candidate in candidates]
    summary = SuggestionSummary(
        company_count=stats["company_count"],
        cluster_count=len(suggestions),
        total_examples=stats["total_examples"],
        average_cluster_size=stats["average_cluster_size"],
        silhouette_score=stats["silhouette_score"],
        suggestions=suggestions,
    )
    save_json(summary.model_dump(), SUGGESTIONS_PATH)
    return summary


def create_pipeline_run(parameters: Dict[str, Any], workspace_id: Optional[int] = None) -> str:
    query = f"""
        INSERT INTO {FAQ_SCHEMA}.pipeline_runs (workspace_id, status, parameters, notes)
        VALUES (%s, 'running', %s, %s)
        RETURNING run_id::text
    """
    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (workspace_id, Json(parameters), "Pipeline manual/API iniciado."))
            return str(cursor.fetchone()[0])


def finish_pipeline_run(run_id: str, status: str, notes: Optional[str] = None) -> None:
    query = f"""
        UPDATE {FAQ_SCHEMA}.pipeline_runs
        SET status = %s, finished_at = now(), notes = COALESCE(%s, notes)
        WHERE run_id = %s
    """
    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (status, notes, run_id))


def insert_metric(cursor: Any, run_id: str, name: str, value: Optional[float], metadata: Optional[Dict[str, Any]] = None) -> None:
    cursor.execute(
        f"""
        INSERT INTO {FAQ_SCHEMA}.pipeline_metrics (run_id, metric_name, metric_value, metric_metadata)
        VALUES (%s, %s, %s, %s)
        """,
        (run_id, name, value, Json(metadata or {})),
    )


def persist_embedding(cursor: Any, candidate: Dict[str, Any], example: Dict[str, Any]) -> int:
    message_pk = example.get("message_pk")
    embedding = example.get("embedding")
    if not message_pk or not embedding:
        return 0

    cursor.execute(
        f"""
        INSERT INTO {FAQ_SCHEMA}.message_embeddings (
            message_pk, workspace_id, agent_id, embedding_model, embedding_dimension, embedding, embedding_metadata
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (message_pk, embedding_model) DO UPDATE SET
            workspace_id = EXCLUDED.workspace_id,
            agent_id = EXCLUDED.agent_id,
            embedding_dimension = EXCLUDED.embedding_dimension,
            embedding = EXCLUDED.embedding,
            embedding_metadata = EXCLUDED.embedding_metadata
        """,
        (
            message_pk,
            candidate["workspace_id"],
            candidate.get("agent_id"),
            EMBEDDING_BACKEND_READY,
            len(embedding),
            embedding,
            Json({"normalized": True, "source": "faq_suggestion_pipeline"}),
        ),
    )
    return 1


def find_existing_candidate(cursor: Any, candidate: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    cursor.execute(
        f"""
        SELECT candidate_id::text, status
        FROM {FAQ_SCHEMA}.faq_candidates
        WHERE workspace_id = %s
          AND COALESCE(agent_id::text, '') = COALESCE(%s, '')
          AND lower(normalized_question) = lower(%s)
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (candidate["workspace_id"], candidate.get("agent_id"), candidate["normalized_question"]),
    )
    row = cursor.fetchone()
    return dict(row) if row else None


def persist_pipeline_results(run_id: str, candidates: List[Dict[str, Any]], stats: Dict[str, Any]) -> List[SuggestionResponse]:
    responses: List[SuggestionResponse] = []
    embeddings_persisted = 0

    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            for candidate in candidates:
                if candidate["workspace_id"] is None:
                    continue

                cursor.execute(
                    f"""
                    INSERT INTO {FAQ_SCHEMA}.question_clusters (
                        run_id, workspace_id, agent_id, cluster_label, algorithm,
                        representative_question, centroid_embedding, cluster_size, cluster_metadata
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING cluster_id::text
                    """,
                    (
                        run_id,
                        candidate["workspace_id"],
                        candidate.get("agent_id"),
                        candidate["cluster_label"],
                        candidate["algorithm"],
                        candidate["normalized_question"],
                        candidate["centroid_embedding"],
                        candidate["cluster_size"],
                        Json(candidate["cluster_metadata"]),
                    ),
                )
                cluster_id = cursor.fetchone()["cluster_id"]
                candidate["cluster_id"] = cluster_id

                existing = find_existing_candidate(cursor, candidate)
                if existing:
                    candidate_id = existing["candidate_id"]
                    cursor.execute(
                        f"""
                        UPDATE {FAQ_SCHEMA}.faq_candidates
                        SET cluster_id = %s,
                            suggested_answer = %s,
                            cluster_label = %s,
                            recurrence_count = %s,
                            first_seen_at = %s,
                            last_seen_at = %s,
                            updated_at = now(),
                            candidate_metadata = candidate_metadata || %s::jsonb
                        WHERE candidate_id = %s
                        """,
                        (
                            cluster_id,
                            candidate["suggested_answer"],
                            candidate["cluster_label"],
                            candidate["recurrence_count"],
                            candidate["first_seen_at"],
                            candidate["last_seen_at"],
                            Json(candidate["candidate_metadata"]),
                            candidate_id,
                        ),
                    )
                    candidate["candidate_id"] = candidate_id
                    candidate["status"] = existing["status"]
                else:
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_candidates (
                            candidate_id, workspace_id, agent_id, cluster_id, normalized_question,
                            suggested_answer, cluster_label, recurrence_count, first_seen_at,
                            last_seen_at, status, candidate_metadata
                        )
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 'pending', %s)
                        RETURNING candidate_id::text, status
                        """,
                        (
                            candidate["candidate_id"],
                            candidate["workspace_id"],
                            candidate.get("agent_id"),
                            cluster_id,
                            candidate["normalized_question"],
                            candidate["suggested_answer"],
                            candidate["cluster_label"],
                            candidate["recurrence_count"],
                            candidate["first_seen_at"],
                            candidate["last_seen_at"],
                            Json(candidate["candidate_metadata"]),
                        ),
                    )
                    created = cursor.fetchone()
                    candidate["candidate_id"] = created["candidate_id"]
                    candidate["status"] = created["status"]
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_validation_events (
                            candidate_id, event_type, previous_status, new_status, reviewer_identifier, notes
                        )
                        VALUES (%s, 'created', NULL, 'pending', 'pipeline', %s)
                        """,
                        (candidate["candidate_id"], f"Generado por pipeline_run={run_id}"),
                    )

                cursor.execute(
                    f"DELETE FROM {FAQ_SCHEMA}.faq_candidate_examples WHERE candidate_id = %s",
                    (candidate["candidate_id"],),
                )
                for example in candidate["examples"]:
                    embeddings_persisted += persist_embedding(cursor, candidate, example)
                    if not example.get("message_pk") or not example.get("conversation_pk"):
                        continue
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_candidate_examples (
                            candidate_id, message_pk, conversation_pk, original_user_message,
                            assistant_response, similarity_score
                        )
                        VALUES (%s, %s, %s, %s, %s, %s)
                        """,
                        (
                            candidate["candidate_id"],
                            example["message_pk"],
                            example["conversation_pk"],
                            example["original_user_message"],
                            example["assistant_response"],
                            example["similarity_score"],
                        ),
                    )
                responses.append(_candidate_to_response(candidate))

            metric_values = {
                "conversations_analyzed": stats.get("conversations_analyzed"),
                "faq_candidate_messages": stats.get("total_examples"),
                "candidates_generated": len(responses),
                "clusters_valid": stats.get("clusters_valid"),
                "clusters_rejected": stats.get("clusters_rejected"),
                "llm_rejected": stats.get("llm_rejected"),
                "validator_rejected": stats.get("validator_rejected"),
                "average_cluster_size": stats.get("average_cluster_size"),
                "duplicates_omitted": stats.get("duplicates_omitted"),
                "workspaces_processed": stats.get("company_count"),
                "embeddings_persisted": embeddings_persisted,
            }
            if stats.get("silhouette_score") is not None:
                metric_values["silhouette_score"] = stats.get("silhouette_score")
            for name, value in metric_values.items():
                insert_metric(cursor, run_id, name, value, {"embedding_backend": EMBEDDING_BACKEND_READY})

    return responses


def list_suggestions_from_db(
    status: Optional[str] = None,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
    include_all: bool = False,
) -> SuggestionSummary:
    filters = []
    params: List[Any] = []
    if not include_all:
        filters.append("qc.run_id = (SELECT run_id FROM latest_successful_run)")
    if status:
        filters.append("fc.status = %s")
        params.append(status)
    if workspace_id is not None:
        filters.append("fc.workspace_id = %s")
        params.append(workspace_id)
    if agent_id:
        filters.append("fc.agent_id = %s")
        params.append(agent_id)
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""

    query = f"""
        WITH latest_successful_run AS (
            SELECT run_id
            FROM {FAQ_SCHEMA}.pipeline_runs
            WHERE status = 'succeeded'
            ORDER BY finished_at DESC NULLS LAST, started_at DESC
            LIMIT 1
        )
        SELECT
            fc.candidate_id::text AS candidate_id,
            fc.workspace_id,
            w.name AS company_name,
            fc.agent_id::text AS agent_id,
            fc.normalized_question,
            fc.suggested_answer,
            fc.recurrence_count,
            fc.status,
            fc.created_at,
            fc.updated_at,
            fc.candidate_metadata,
            qc.run_id::text AS run_id,
            COALESCE(
                array_remove(array_agg(fce.original_user_message ORDER BY fce.similarity_score DESC NULLS LAST), NULL),
                ARRAY[]::text[]
            ) AS support_examples
        FROM {FAQ_SCHEMA}.faq_candidates AS fc
        JOIN {FAQ_SCHEMA}.workspaces AS w
          ON w.workspace_id = fc.workspace_id
        LEFT JOIN {FAQ_SCHEMA}.question_clusters AS qc
          ON qc.cluster_id = fc.cluster_id
        LEFT JOIN {FAQ_SCHEMA}.faq_candidate_examples AS fce
          ON fce.candidate_id = fc.candidate_id
        {where_clause}
        GROUP BY
            fc.candidate_id, fc.workspace_id, w.name, fc.agent_id, fc.normalized_question,
            fc.suggested_answer, fc.recurrence_count, fc.status, fc.created_at, fc.updated_at,
            fc.candidate_metadata, qc.run_id
        ORDER BY fc.created_at DESC
    """

    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(query, tuple(params))
            rows = [dict(row) for row in cursor.fetchall()]

    suggestions = []
    for row in rows:
        metadata = row.get("candidate_metadata") or {}
        suggestions.append(
            SuggestionResponse(
                id=row["candidate_id"],
                company_id=str(row["workspace_id"]),
                company_name=row.get("company_name"),
                workspace_id=int(row["workspace_id"]),
                agent_id=row.get("agent_id"),
                question=row["normalized_question"],
                answer=row.get("suggested_answer") or "",
                cluster_size=int(row.get("recurrence_count") or 0),
                support_examples=list(row.get("support_examples") or [])[:3],
                cluster_score=float(metadata.get("cluster_score") or 0.0),
                status=row.get("status", "pending"),
                created_at=row.get("created_at"),
                updated_at=row.get("updated_at"),
                run_id=row.get("run_id"),
            )
        )

    company_count = len({item.company_id for item in suggestions})
    total_examples = sum(item.cluster_size for item in suggestions)
    return SuggestionSummary(
        company_count=company_count,
        cluster_count=len(suggestions),
        total_examples=total_examples,
        average_cluster_size=round(total_examples / len(suggestions), 2) if suggestions else 0.0,
        silhouette_score=None,
        suggestions=suggestions,
        run_id=suggestions[0].run_id if suggestions else None,
    )


def run_suggestion_pipeline(request: Optional[IngestRequest] = None) -> SuggestionSummary:
    request = request or IngestRequest()
    parameters = {
        "limit": request.limit,
        "since_days": request.since_days,
        "workspace_id": request.workspace_id,
        "agent_id": request.agent_id,
        "embedding_model": MODEL_NAME,
        "embedding_backend": FAQ_EMBEDDING_BACKEND,
        "cluster_eps": FAQ_CLUSTER_EPS,
        "min_cluster_size": FAQ_MIN_CLUSTER_SIZE,
        "skip_existing": FAQ_SKIP_EXISTING,
        "duplicate_threshold": FAQ_DUPLICATE_THRESHOLD,
        "llm_enabled": FAQ_LLM_ENABLED,
        "llm_model": FAQ_LLM_MODEL,
    }
    run_id = create_pipeline_run(parameters, workspace_id=request.workspace_id)
    try:
        conversations = fetch_conversation_records(
            limit=request.limit,
            since_days=request.since_days,
            workspace_id=request.workspace_id,
            agent_id=request.agent_id,
        )
        candidates, stats = build_suggestion_candidates(
            conversations,
            existing_faqs_by_company=load_existing_faqs_by_company(),
            run_id=run_id,
        )
        suggestions = persist_pipeline_results(run_id, candidates, stats)
        finish_pipeline_run(run_id, "succeeded", f"Generados {len(suggestions)} candidatos.")
        summary = SuggestionSummary(
            company_count=stats["company_count"],
            cluster_count=len(suggestions),
            total_examples=stats["total_examples"],
            average_cluster_size=round(stats["total_examples"] / len(suggestions), 2) if suggestions else 0.0,
            silhouette_score=stats["silhouette_score"],
            suggestions=suggestions,
            run_id=run_id,
        )
        save_json(summary.model_dump(), SUGGESTIONS_PATH)
        return summary
    except Exception as exc:
        finish_pipeline_run(run_id, "failed", str(exc))
        raise


def load_conversation_pairs() -> List[Dict[str, Any]]:
    if not CONVERSATIONS_PATH.exists():
        raise FileNotFoundError(f"Conversation file not found: {CONVERSATIONS_PATH}")
    return load_json_lines(CONVERSATIONS_PATH)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "suggestion",
        "source_schema": FAQ_SCHEMA,
        "embedding_model": MODEL_NAME,
        "embedding_backend": EMBEDDING_BACKEND_READY,
        "answer_model": FAQ_LLM_MODEL if ANSWER_GENERATOR else "historical_fallback",
    }


@app.post("/suggest", response_model=SuggestionSummary)
def suggest(request: Optional[IngestRequest] = None) -> SuggestionSummary:
    try:
        return run_suggestion_pipeline(request)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"No se pudo generar sugerencias: {exc}") from exc


@app.get("/suggestions", response_model=SuggestionSummary)
def get_suggestions(
    status: Optional[str] = None,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
    include_all: bool = False,
) -> SuggestionSummary:
    if status and status not in {"pending", "approved", "rejected", "needs_review"}:
        raise HTTPException(status_code=400, detail="Invalid status filter.")
    return list_suggestions_from_db(
        status=status,
        workspace_id=workspace_id,
        agent_id=agent_id,
        include_all=include_all,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("suggestion_service:app", host="127.0.0.1", port=8003, log_level="info")
