from datetime import datetime

from fastapi.testclient import TestClient

import validation_service as svc
from faq_models import SuggestionResponse, SuggestionSummary, ValidationResponse


def test_health_endpoint():
    client = TestClient(svc.app)

    response = client.get("/health")

    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_get_suggestions_endpoint(monkeypatch):
    summary = SuggestionSummary(
        company_count=1,
        cluster_count=1,
        total_examples=3,
        average_cluster_size=3,
        silhouette_score=None,
        suggestions=[
            SuggestionResponse(
                id="11111111-1111-1111-1111-111111111111",
                company_id="74",
                company_name="Empire Box",
                workspace_id=74,
                question="Quiero reservar una clase",
                answer="La reserva se realiza por el canal oficial.",
                cluster_size=3,
                support_examples=["Quiero reservar una clase"],
                cluster_score=75.0,
            )
        ],
    )
    captured_kwargs = {}

    def fake_list_suggestions_from_db(**kwargs):
        captured_kwargs.update(kwargs)
        return summary

    monkeypatch.setattr(svc, "list_suggestions_from_db", fake_list_suggestions_from_db)
    client = TestClient(svc.app)

    response = client.get("/suggestions")

    assert response.status_code == 200
    assert response.json()[0]["id"] == "11111111-1111-1111-1111-111111111111"
    assert captured_kwargs["include_all"] is False


def test_post_validate_endpoint(monkeypatch):
    response_model = ValidationResponse(
        suggestion_id="11111111-1111-1111-1111-111111111111",
        reviewer="Ana",
        status="approved",
        previous_status="pending",
        notes=None,
        reviewed_at=datetime(2026, 5, 14, 12, 0, 0),
        promoted_faq_id="11111111-1111-1111-1111-111111111111",
    )
    monkeypatch.setattr(svc, "apply_validation", lambda request: response_model)
    client = TestClient(svc.app)

    response = client.post(
        "/validate",
        json={
            "suggestion_id": "11111111-1111-1111-1111-111111111111",
            "reviewer": "Ana",
            "status": "approved",
        },
    )

    assert response.status_code == 200
    assert response.json()["status"] == "approved"
    assert response.json()["promoted_faq_id"] == "11111111-1111-1111-1111-111111111111"
