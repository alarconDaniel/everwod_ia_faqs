import pytest

import suggestion_service as svc


class FakeTokenizer:
    eos_token_id = 0

    def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True):
        return "prompt"


class FakeGenerator:
    tokenizer = FakeTokenizer()

    def __init__(self, text):
        self.text = text

    def __call__(self, *args, **kwargs):
        return [{"generated_text": self.text}]


@pytest.fixture(autouse=True)
def lightweight_models(monkeypatch):
    svc.MODELS_READY = True
    svc.EMBEDDING_MODEL = None
    svc.ANSWER_GENERATOR = None
    svc.EMBEDDING_BACKEND_READY = "hash"
    monkeypatch.setattr(svc, "load_models", lambda: None)


def test_candidate_filter_rejects_noise_and_accepts_business_question():
    assert not svc.is_good_faq_candidate("hola")
    assert not svc.is_good_faq_candidate("Gracias por la informacion")
    assert not svc.is_good_faq_candidate("mi correo es cliente@example.com")
    assert svc.is_good_faq_candidate("Quiero reservar una clase de cortesia")


def test_raw_question_can_be_cleaned_to_canonical_question():
    question = svc.clean_canonical_question("Quisiera agendar una clase de prueba mañana 6.30 am")

    assert "mañana" not in question.lower()
    assert "6.30" not in question
    assert question == "¿Cómo puedo agendar una clase de prueba?"
    assert svc.is_valid_canonical_question(question)


def test_half_payment_raw_question_can_be_canonicalized():
    question = svc.clean_canonical_question("Puedo pagar con la mitad")

    assert question == "¿Es posible reservar pagando un anticipo?"
    assert svc.is_valid_canonical_question(question)


def test_existing_faq_deduplicates_exact_normalized_question():
    assert svc.is_existing_faq(
        "¿Cómo puedo reservar una clase?",
        ["Como puedo reservar una clase"],
    )


def test_redacts_pii_from_examples():
    text = "Hola Juan Perez, escribe a cliente@example.com o al 300 123 4567"
    redacted = svc.redact_personal_data(text)

    assert "Juan Perez" not in redacted
    assert "cliente@example.com" not in redacted
    assert "300 123 4567" not in redacted
    assert "[correo]" in redacted
    assert "[telefono]" in redacted


@pytest.mark.parametrize(
    "answer",
    [
        "Tu tóxica de confianza 😏; pagas directo en www.severasmedias.com",
        "¡Hola! Mi nombre es Luciana 😊 Estoy aquí para ayudarte con tus desayunos.",
        "¿Para qué ciudad lo necesitas?",
        "Envíame el soporte para dejarte confirmado el jueves a las 7:00 am.",
    ],
)
def test_conversational_answers_are_rejected(answer):
    assert not svc.is_valid_canonical_answer(answer)


def test_placeholders_are_rejected():
    assert not svc.is_valid_canonical_answer("La reserva se confirma llamando a [telefono].")
    assert not svc.is_valid_canonical_answer("La respuesta se envia al [correo] registrado.")


def test_tool_traces_are_rejected():
    trace = "Reasoning function_call getSchedules."

    assert svc.is_internal_tool_trace(trace)
    assert not svc.is_valid_canonical_answer(trace)


def test_clean_faq_answer_removes_personal_greeting_and_name():
    answer = "Hola Juan, para tu día de cortesía te ayudamos a reservar por WhatsApp"

    cleaned = svc.clean_faq_answer(answer)

    assert "Hola" not in cleaned
    assert "Juan" not in cleaned
    assert "te ayudamos" not in cleaned.lower()
    assert cleaned.startswith("Para el día de cortesía")


def test_parse_valid_llm_json():
    raw = '{"publish": true, "canonical_question": "¿Cómo puedo pagar por Nequi?", "canonical_answer": "Los pagos por Nequi pueden realizarse cuando el negocio tenga este metodo habilitado.", "confidence": 0.82, "reason": "Evidencia consistente."}'

    parsed = svc.parse_llm_faq_candidate(raw)

    assert parsed is not None
    assert parsed["publish"] is True
    assert parsed["canonical_question"] == "¿Cómo puedo pagar por Nequi?"
    assert parsed["confidence"] == 0.82


def test_parse_llm_json_surrounded_by_text():
    raw = 'Claro. {"publish": false, "canonical_question": "", "canonical_answer": "", "confidence": 0.21, "reason": "Cluster mezclado."} listo'

    parsed = svc.parse_llm_faq_candidate(raw)

    assert parsed is not None
    assert parsed["publish"] is False
    assert parsed["reason"] == "Cluster mezclado."


def test_invalid_llm_json_returns_none():
    assert svc.parse_llm_faq_candidate("{publish: true") is None


def test_publish_false_is_not_valid_generation():
    parsed = svc.parse_llm_faq_candidate(
        '{"publish": false, "canonical_question": "", "canonical_answer": "", "confidence": 0.25, "reason": "No hay evidencia."}'
    )

    is_valid, reason = svc.validate_generated_candidate(parsed)

    assert not is_valid
    assert reason == "llm_publish_false"


def test_incoherent_cluster_is_rejected():
    mixed, reason = svc.is_mixed_intent_cluster(
        [
            "Hola tienen los desayunos sorpresa?",
            "Los precios ya incluyen el domicilio?",
            "Que precio tiene el envio a Chia?",
        ]
    )

    assert mixed
    assert "mezcla" in reason.lower()


def test_fallback_without_qwen_does_not_publish_raw_dump_answer():
    result = svc.generate_faq_candidate_with_llm(
        company_name="Empire Box",
        questions=["Cómo hago para pagar por Nequi?"],
        historical_answers=["Tu tóxica de confianza 😏; pagas directo y te paso el link."],
        cluster_metrics={"cluster_cohesion": 0.9},
        recurrence=3,
    )

    assert result["publish"] is False
    assert result["canonical_answer"] == ""


def test_llm_generates_complete_publishable_candidate(monkeypatch):
    svc.ANSWER_GENERATOR = FakeGenerator(
        '{"publish": true, "canonical_question": "¿Cómo puedo agendar una clase de prueba?", "canonical_answer": "Las clases de prueba pueden agendarse segun la disponibilidad y los horarios definidos por el negocio.", "confidence": 0.87, "reason": "El cluster trata sobre agendamiento de clases de prueba."}'
    )

    result = svc.generate_faq_candidate_with_llm(
        company_name="Empire Box",
        questions=[
            "Quisiera agendar una clase de prueba mañana 6.30 am",
            "Quiero reservar una clase de prueba",
            "Como puedo agendar clase de cortesia?",
        ],
        historical_answers=[
            "La clase de prueba se agenda segun disponibilidad del negocio.",
            "Las reservas de clase de prueba dependen de los horarios disponibles.",
        ],
        cluster_metrics={"cluster_cohesion": 0.9},
        recurrence=3,
    )

    is_valid, reason = svc.validate_generated_candidate(result)

    assert result["publish"] is True
    assert result["canonical_question"] == "¿Cómo puedo agendar una clase de prueba?"
    assert is_valid, reason


def test_build_company_candidates_uses_canonical_question_and_answer(monkeypatch):
    svc.ANSWER_GENERATOR = FakeGenerator(
        '{"publish": true, "canonical_question": "¿Cómo puedo agendar una clase de prueba?", "canonical_answer": "Las clases de prueba pueden agendarse segun la disponibilidad y los horarios definidos por el negocio.", "confidence": 0.9, "reason": "Evidencia consistente."}'
    )
    monkeypatch.setattr(svc, "encode_texts", lambda texts: [[1.0, 0.0] for _ in texts])
    monkeypatch.setattr(svc, "cluster_embeddings", lambda embeddings: [0 for _ in embeddings])
    monkeypatch.setattr(svc, "compute_silhouette", lambda embeddings, labels: None)
    monkeypatch.setattr(svc, "is_existing_faq", lambda question, existing: False)

    conversations = [
        {
            "workspace_id": 74,
            "company_id": "74",
            "company_name": "Empire Box",
            "agent_id": "agent-1",
            "conversation_pk": index,
            "user_message_pk": index,
            "user_text": text,
            "assistant_text": "La clase de prueba se agenda segun disponibilidad del negocio.",
            "created_at": "2026-05-14T10:00:00",
        }
        for index, text in enumerate(
            [
                "Quisiera agendar una clase de prueba mañana 6.30 am",
                "Quiero reservar una clase de prueba",
                "Como puedo agendar clase de cortesia?",
            ],
            start=1,
        )
    ]

    candidates, stats = svc.build_company_candidates(conversations, existing_questions=[], run_id="run-1")

    assert len(candidates) == 1
    assert candidates[0]["normalized_question"] == "¿Cómo puedo agendar una clase de prueba?"
    assert candidates[0]["suggested_answer"].startswith("Las clases de prueba")
    assert candidates[0]["candidate_metadata"]["generation_confidence"] == 0.9
    assert stats["clusters_valid"] == 1
