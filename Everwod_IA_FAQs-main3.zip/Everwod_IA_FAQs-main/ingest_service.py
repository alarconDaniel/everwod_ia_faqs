from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any, Dict, Iterable, List, Optional

from fastapi import FastAPI
from psycopg2.extras import RealDictCursor

from faq_common import DATA_DIR, FAQ_SCHEMA, configure_cors, get_db_connection, normalize_text, save_json_lines
from faq_models import IngestRequest, IngestResponse


app = FastAPI(title="Everwod FAQ Ingestion Service")
configure_cors(app)

OUTPUT_PATH = DATA_DIR / "conversations.jsonl"


def _event_sort_key(event: Dict[str, Any]) -> tuple:
    return (
        event.get("conversation_pk") or 0,
        event.get("created_at") or datetime.min,
        event.get("message_pk") or 0,
    )


def pair_user_assistant_messages(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    messages_by_conversation: Dict[int, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        text = normalize_text(row.get("content_text"))
        role = normalize_text(row.get("role")).lower()
        conversation_pk = row.get("conversation_pk")
        if not conversation_pk or role not in {"user", "assistant"} or not text:
            continue
        clean_row = dict(row)
        clean_row["content_text"] = text
        clean_row["role"] = role
        messages_by_conversation[int(conversation_pk)].append(clean_row)

    pairs: List[Dict[str, Any]] = []
    for conversation_pk, events in messages_by_conversation.items():
        last_user: Optional[Dict[str, Any]] = None
        for event in sorted(events, key=_event_sort_key):
            if event["role"] == "user":
                last_user = event
                continue

            if event["role"] == "assistant" and last_user:
                workspace_id = last_user.get("workspace_id")
                pairs.append(
                    {
                        "company_id": str(workspace_id) if workspace_id is not None else "unknown",
                        "workspace_id": workspace_id,
                        "company_name": last_user.get("company_name"),
                        "agent_id": str(last_user["agent_id"]) if last_user.get("agent_id") else None,
                        "conversation_id": str(last_user.get("conversation_id") or ""),
                        "conversation_pk": conversation_pk,
                        "user_message_pk": last_user.get("message_pk"),
                        "assistant_message_pk": event.get("message_pk"),
                        "user_text": last_user["content_text"],
                        "assistant_text": event["content_text"],
                        "created_at": last_user.get("created_at").isoformat()
                        if last_user.get("created_at")
                        else None,
                        "assistant_created_at": event.get("created_at").isoformat()
                        if event.get("created_at")
                        else None,
                    }
                )
                last_user = None

    return pairs


def fetch_message_rows(
    limit: int = 15000,
    since_days: int = 90,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    since = datetime.utcnow() - timedelta(days=since_days)
    params: List[Any] = [since]
    filters = [
        "m.created_at >= %s",
        "m.role IN ('user', 'assistant')",
        "m.content_text IS NOT NULL",
        "btrim(m.content_text) <> ''",
    ]

    if workspace_id is not None:
        filters.append("c.workspace_id = %s")
        params.append(workspace_id)
    if agent_id:
        filters.append("c.agent_id = %s")
        params.append(agent_id)

    params.append(limit)
    query = f"""
        SELECT
            m.message_pk,
            m.conversation_pk,
            c.source_agent_chat_id::text AS conversation_id,
            c.workspace_id,
            w.name AS company_name,
            c.agent_id::text AS agent_id,
            m.role,
            m.content_text,
            m.created_at
        FROM {FAQ_SCHEMA}.messages AS m
        JOIN {FAQ_SCHEMA}.conversations AS c
          ON c.conversation_pk = m.conversation_pk
        JOIN {FAQ_SCHEMA}.workspaces AS w
          ON w.workspace_id = c.workspace_id
        WHERE {" AND ".join(filters)}
        ORDER BY c.workspace_id, m.conversation_pk, m.created_at, m.message_pk
        LIMIT %s
    """

    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(query, tuple(params))
            return [dict(row) for row in cursor.fetchall()]


def fetch_conversation_records(
    limit: int = 15000,
    since_days: int = 90,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
) -> List[Dict[str, Any]]:
    rows = fetch_message_rows(
        limit=limit,
        since_days=since_days,
        workspace_id=workspace_id,
        agent_id=agent_id,
    )
    return pair_user_assistant_messages(rows)


def ingest(
    limit: int = 15000,
    since_days: int = 90,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
) -> IngestResponse:
    records = fetch_conversation_records(
        limit=limit,
        since_days=since_days,
        workspace_id=workspace_id,
        agent_id=agent_id,
    )
    save_json_lines(records, OUTPUT_PATH)
    return IngestResponse(imported_records=len(records), output_file=str(OUTPUT_PATH))


@app.get("/health")
def health() -> dict:
    return {"status": "ok", "service": "ingest", "source_schema": FAQ_SCHEMA}


@app.post("/ingest", response_model=IngestResponse)
def run_ingest(request: IngestRequest) -> IngestResponse:
    return ingest(
        limit=request.limit,
        since_days=request.since_days,
        workspace_id=request.workspace_id,
        agent_id=request.agent_id,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("ingest_service:app", host="127.0.0.1", port=8001, log_level="info")
