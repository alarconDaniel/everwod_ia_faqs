from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, Field


ValidationStatus = Literal["approved", "rejected", "needs_review"]
CandidateStatus = Literal["pending", "approved", "rejected", "needs_review"]
QualityTier = Literal["high_confidence", "needs_review"]


class IngestRequest(BaseModel):
    limit: int = Field(15000, ge=1, le=50000)
    since_days: int = Field(90, ge=1, le=3650)
    workspace_id: Optional[int] = None
    agent_id: Optional[str] = None


class IngestResponse(BaseModel):
    imported_records: int
    output_file: str
    source_schema: str = "faq_mvp"


class EncodeRequest(BaseModel):
    texts: List[str]


class EncodeResponse(BaseModel):
    embeddings: List[List[float]]
    count: int


class SuggestionResponse(BaseModel):
    id: str
    company_id: str
    company_name: Optional[str] = None
    workspace_id: int
    agent_id: Optional[str] = None
    question: str
    answer: str
    cluster_size: int
    support_examples: List[str]
    cluster_score: float
    quality_tier: Optional[QualityTier] = None
    review_reason: Optional[str] = None
    generation_confidence: Optional[float] = None
    knowledge_statement: Optional[str] = None
    since_days_used: Optional[int] = None
    was_human_edited: bool = False
    last_edited_by: Optional[str] = None
    last_edited_at: Optional[datetime] = None
    edit_count: int = 0
    status: CandidateStatus = "pending"
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    run_id: Optional[str] = None


class SuggestionSummary(BaseModel):
    company_count: int
    cluster_count: int
    total_examples: int
    average_cluster_size: float
    silhouette_score: Optional[float]
    suggestions: List[SuggestionResponse]
    run_id: Optional[str] = None


class WorkspaceResponse(BaseModel):
    workspace_id: int
    workspace_name: str
    company_id: str


class ValidationRequest(BaseModel):
    suggestion_id: str
    reviewer: str = Field(..., min_length=1, max_length=255)
    status: ValidationStatus
    notes: Optional[str] = None
    reviewed_at: Optional[datetime] = None
    edited_question: Optional[str] = None
    edited_answer: Optional[str] = None


class ValidationResponse(BaseModel):
    suggestion_id: str
    reviewer: str
    status: ValidationStatus
    previous_status: CandidateStatus
    notes: Optional[str] = None
    reviewed_at: datetime
    promoted_faq_id: Optional[str] = None


class ValidationRecord(BaseModel):
    id: str
    suggestion_id: str
    reviewer: Optional[str] = None
    status: CandidateStatus
    previous_status: Optional[CandidateStatus] = None
    notes: Optional[str] = None
    created_at: datetime
    question_summary: str


class SuggestionEditRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=500)
    answer: str = Field(..., min_length=3, max_length=2000)
    editor: str = Field(..., min_length=1, max_length=255)
    notes: Optional[str] = None


class SuggestionEditResponse(BaseModel):
    suggestion_id: str
    question: str
    answer: str
    editor: str
    notes: Optional[str] = None
    was_human_edited: bool
    last_edited_at: datetime
