from datetime import datetime, timedelta

from ingest_service import pair_user_assistant_messages


def test_pairs_last_user_with_next_assistant_and_ignores_empty_messages():
    now = datetime(2026, 5, 14, 10, 0, 0)
    rows = [
        {
            "message_pk": 1,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Empire Box",
            "agent_id": "agent-1",
            "role": "user",
            "content_text": "Hola",
            "created_at": now,
        },
        {
            "message_pk": 2,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Empire Box",
            "agent_id": "agent-1",
            "role": "user",
            "content_text": "Quiero reservar una clase",
            "created_at": now + timedelta(seconds=1),
        },
        {
            "message_pk": 3,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Empire Box",
            "agent_id": "agent-1",
            "role": "assistant",
            "content_text": "Claro, estas son las opciones.",
            "created_at": now + timedelta(seconds=2),
        },
        {
            "message_pk": 4,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Empire Box",
            "agent_id": "agent-1",
            "role": "assistant",
            "content_text": "",
            "created_at": now + timedelta(seconds=3),
        },
    ]

    pairs = pair_user_assistant_messages(rows)

    assert len(pairs) == 1
    assert pairs[0]["user_text"] == "Quiero reservar una clase"
    assert pairs[0]["assistant_text"] == "Claro, estas son las opciones."
    assert pairs[0]["user_message_pk"] == 2
    assert pairs[0]["conversation_pk"] == 10


def test_pairs_keep_workspace_separation():
    now = datetime(2026, 5, 14, 10, 0, 0)
    rows = [
        {
            "message_pk": 1,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Workspace A",
            "agent_id": "agent-a",
            "role": "user",
            "content_text": "Quiero informacion de planes",
            "created_at": now,
        },
        {
            "message_pk": 2,
            "conversation_pk": 10,
            "conversation_id": "chat-1",
            "workspace_id": 74,
            "company_name": "Workspace A",
            "agent_id": "agent-a",
            "role": "assistant",
            "content_text": "Respuesta A",
            "created_at": now + timedelta(seconds=1),
        },
        {
            "message_pk": 3,
            "conversation_pk": 20,
            "conversation_id": "chat-2",
            "workspace_id": 75,
            "company_name": "Workspace B",
            "agent_id": "agent-b",
            "role": "user",
            "content_text": "Quiero informacion de planes",
            "created_at": now,
        },
        {
            "message_pk": 4,
            "conversation_pk": 20,
            "conversation_id": "chat-2",
            "workspace_id": 75,
            "company_name": "Workspace B",
            "agent_id": "agent-b",
            "role": "assistant",
            "content_text": "Respuesta B",
            "created_at": now + timedelta(seconds=1),
        },
    ]

    pairs = pair_user_assistant_messages(rows)

    assert {pair["workspace_id"] for pair in pairs} == {74, 75}
    assert {pair["company_id"] for pair in pairs} == {"74", "75"}
