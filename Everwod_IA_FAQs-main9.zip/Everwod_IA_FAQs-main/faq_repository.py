from collections import defaultdict
from typing import Any, Dict, List, Optional

from psycopg2.extras import Json, RealDictCursor

from faq_common import FAQ_SCHEMA, get_db_connection, normalize_text
from faq_config import FAQ_EMBEDDING_BACKEND, FAQ_SKIP_EXISTING, FAQ_SKIP_REJECTED, MODEL_NAME
from faq_embeddings import encode_texts, current_embedding_model_label
from faq_models import SuggestionResponse, SuggestionSummary, WorkspaceResponse
from faq_quality import QUALITY_METRIC_KEYS, deduplicate_support_example_texts


def _candidate_to_response(candidate: Dict[str, Any]) -> SuggestionResponse:
    metadata = candidate.get("candidate_metadata") or {}
    support_examples, _deduplicated = deduplicate_support_example_texts(candidate.get("support_examples") or [], limit=3)
    return SuggestionResponse(
        id=str(candidate["candidate_id"]),
        company_id=str(candidate.get("company_id") or candidate.get("workspace_id")),
        company_name=candidate.get("company_name"),
        workspace_id=int(candidate["workspace_id"]),
        agent_id=str(candidate["agent_id"]) if candidate.get("agent_id") else None,
        question=candidate["normalized_question"],
        answer=candidate.get("suggested_answer") or "",
        cluster_size=int(candidate.get("recurrence_count") or candidate.get("cluster_size") or 0),
        support_examples=support_examples,
        cluster_score=float(candidate.get("cluster_score") or 0.0),
        quality_tier=metadata.get("quality_tier"),
        review_reason=metadata.get("review_reason"),
        review_reason_code=metadata.get("review_reason_code"),
        generation_confidence=metadata.get("generation_confidence"),
        cluster_intent_statement=metadata.get("cluster_intent_statement"),
        knowledge_statement=metadata.get("knowledge_statement"),
        cluster_question_alignment=metadata.get("cluster_question_alignment"),
        candidate_kind=metadata.get("candidate_kind") or "full_faq",
        requires_answer_review=bool(metadata.get("requires_answer_review") or False),
        support_level=metadata.get("support_level"),
        repaired=bool(metadata.get("repaired") or False),
        since_days_used=metadata.get("since_days"),
        was_human_edited=bool(candidate.get("was_human_edited") or False),
        last_edited_by=candidate.get("last_edited_by"),
        last_edited_at=candidate.get("last_edited_at"),
        edit_count=int(candidate.get("edit_count") or 0),
        status=candidate.get("status", "pending"),
        created_at=candidate.get("created_at"),
        updated_at=candidate.get("updated_at"),
        run_id=candidate.get("run_id"),
    )

def create_pipeline_run(parameters: Dict[str, Any], workspace_id: Optional[int] = None) -> str:
    query = f"""
        INSERT INTO {FAQ_SCHEMA}.pipeline_runs (workspace_id, status, parameters, notes)
        VALUES (%s, 'running', %s, %s)
        RETURNING run_id::text
    """

    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(
                query,
                (
                    workspace_id,
                    Json(parameters),
                    "Pipeline manual/API iniciado.",
                ),
            )

            row = cursor.fetchone()
            if row is None:
                raise RuntimeError("No se pudo crear pipeline_run: PostgreSQL no devolvió run_id.")

            return str(row[0])

def finish_pipeline_run(run_id: str, status: str, notes: Optional[str] = None) -> None:
    query = f"""
        UPDATE {FAQ_SCHEMA}.pipeline_runs
        SET status = %s, finished_at = now(), notes = COALESCE(%s, notes)
        WHERE run_id = %s
    """
    with get_db_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, (status, notes, run_id))

def insert_metric(cursor: Any, run_id: str, name: str, value: Optional[float], metadata: Optional[Dict[str, Any]] = None) -> None:
    cursor.execute(
        f"""
        INSERT INTO {FAQ_SCHEMA}.pipeline_metrics (run_id, metric_name, metric_value, metric_metadata)
        VALUES (%s, %s, %s, %s)
        """,
        (run_id, name, value, Json(metadata or {})),
    )

def persist_embedding(cursor: Any, candidate: Dict[str, Any], example: Dict[str, Any]) -> int:
    message_pk = example.get("message_pk")
    embedding = example.get("embedding")
    if not message_pk or not embedding:
        return 0

    cursor.execute(
        f"""
        INSERT INTO {FAQ_SCHEMA}.message_embeddings (
            message_pk, workspace_id, agent_id, embedding_model, embedding_dimension, embedding, embedding_metadata
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (message_pk, embedding_model) DO UPDATE SET
            workspace_id = EXCLUDED.workspace_id,
            agent_id = EXCLUDED.agent_id,
            embedding_dimension = EXCLUDED.embedding_dimension,
            embedding = EXCLUDED.embedding,
            embedding_metadata = EXCLUDED.embedding_metadata
        """,
        (
            message_pk,
            candidate["workspace_id"],
            candidate.get("agent_id"),
            EMBEDDING_BACKEND_READY,
            len(embedding),
            embedding,
            Json({"normalized": True, "source": "faq_suggestion_pipeline"}),
        ),
    )
    return 1

def find_existing_candidate(cursor: Any, candidate: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    cursor.execute(
        f"""
        SELECT candidate_id::text, status
        FROM {FAQ_SCHEMA}.faq_candidates
        WHERE workspace_id = %s
          AND COALESCE(agent_id::text, '') = COALESCE(%s, '')
          AND lower(normalized_question) = lower(%s)
        ORDER BY created_at DESC
        LIMIT 1
        """,
        (candidate["workspace_id"], candidate.get("agent_id"), candidate["normalized_question"]),
    )
    row = cursor.fetchone()
    return dict(row) if row else None

def persist_pipeline_results(run_id: str, candidates: List[Dict[str, Any]], stats: Dict[str, Any]) -> List[SuggestionResponse]:
    responses: List[SuggestionResponse] = []
    embeddings_persisted = 0

    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            for candidate in candidates:
                if candidate["workspace_id"] is None:
                    continue

                cursor.execute(
                    f"""
                    INSERT INTO {FAQ_SCHEMA}.question_clusters (
                        run_id, workspace_id, agent_id, cluster_label, algorithm,
                        representative_question, centroid_embedding, cluster_size, cluster_metadata
                    )
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING cluster_id::text
                    """,
                    (
                        run_id,
                        candidate["workspace_id"],
                        candidate.get("agent_id"),
                        candidate["cluster_label"],
                        candidate["algorithm"],
                        candidate["normalized_question"],
                        candidate["centroid_embedding"],
                        candidate["cluster_size"],
                        Json(candidate["cluster_metadata"]),
                    ),
                )
                cluster_row = cursor.fetchone()
                if cluster_row is None:
                    raise RuntimeError("No se pudo crear question_cluster: PostgreSQL no devolvió cluster_id.")

                cluster_id = str(cluster_row["cluster_id"])
                candidate["cluster_id"] = cluster_id

                existing = find_existing_candidate(cursor, candidate)
                if existing:
                    candidate_id = existing["candidate_id"]
                    next_status = (
                        "needs_review"
                        if existing["status"] == "pending" and candidate.get("status") == "needs_review"
                        else existing["status"]
                    )
                    cursor.execute(
                        f"""
                        UPDATE {FAQ_SCHEMA}.faq_candidates
                        SET cluster_id = %s,
                            suggested_answer = %s,
                            cluster_label = %s,
                            recurrence_count = %s,
                            first_seen_at = %s,
                            last_seen_at = %s,
                            status = %s,
                            updated_at = now(),
                            candidate_metadata = COALESCE(candidate_metadata, '{{}}'::jsonb) || %s::jsonb
                        WHERE candidate_id = %s
                        """,
                        (
                            cluster_id,
                            candidate["suggested_answer"],
                            candidate["cluster_label"],
                            candidate["recurrence_count"],
                            candidate["first_seen_at"],
                            candidate["last_seen_at"],
                            next_status,
                            Json(candidate["candidate_metadata"]),
                            candidate_id,
                        ),
                    )
                    candidate["candidate_id"] = candidate_id
                    candidate["status"] = next_status
                else:
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_candidates (
                            candidate_id, workspace_id, agent_id, cluster_id, normalized_question,
                            suggested_answer, cluster_label, recurrence_count, first_seen_at,
                            last_seen_at, status, candidate_metadata
                        )
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        RETURNING candidate_id::text, status
                        """,
                        (
                            candidate["candidate_id"],
                            candidate["workspace_id"],
                            candidate.get("agent_id"),
                            cluster_id,
                            candidate["normalized_question"],
                            candidate["suggested_answer"],
                            candidate["cluster_label"],
                            candidate["recurrence_count"],
                            candidate["first_seen_at"],
                            candidate["last_seen_at"],
                            candidate.get("status", "pending"),
                            Json(candidate["candidate_metadata"]),
                        ),
                    )
                    created = cursor.fetchone()
                    if created is None:
                        raise RuntimeError("No se pudo crear faq_candidate: PostgreSQL no devolvió candidate_id.")

                    candidate["candidate_id"] = str(created["candidate_id"])
                    candidate["status"] = str(created["status"])
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_validation_events (
                            candidate_id, event_type, previous_status, new_status, reviewer_identifier, notes
                        )
                        VALUES (%s, 'created', NULL, %s, 'pipeline', %s)
                        """,
                        (
                            candidate["candidate_id"],
                            candidate.get("status", "pending"),
                            f"Generado por pipeline_run={run_id}",
                        ),
                    )

                cursor.execute(
                    f"DELETE FROM {FAQ_SCHEMA}.faq_candidate_examples WHERE candidate_id = %s",
                    (candidate["candidate_id"],),
                )
                for example in candidate["examples"]:
                    embeddings_persisted += persist_embedding(cursor, candidate, example)
                    if not example.get("message_pk") or not example.get("conversation_pk"):
                        continue
                    cursor.execute(
                        f"""
                        INSERT INTO {FAQ_SCHEMA}.faq_candidate_examples (
                            candidate_id, message_pk, conversation_pk, original_user_message,
                            assistant_response, similarity_score
                        )
                        VALUES (%s, %s, %s, %s, %s, %s)
                        """,
                        (
                            candidate["candidate_id"],
                            example["message_pk"],
                            example["conversation_pk"],
                            example["original_user_message"],
                            example["assistant_response"],
                            example["similarity_score"],
                        ),
                    )
                responses.append(_candidate_to_response(candidate))

            metric_values = {
                "conversations_analyzed": stats.get("conversations_analyzed"),
                "faq_candidate_messages": stats.get("total_examples"),
                "candidates_generated": len(responses),
                "clusters_valid": stats.get("clusters_valid"),
                "clusters_rejected": stats.get("clusters_rejected"),
                "llm_rejected": stats.get("llm_rejected"),
                "validator_rejected": stats.get("validator_rejected"),
                "average_cluster_size": stats.get("average_cluster_size"),
                "duplicates_omitted": stats.get("duplicates_omitted"),
                "workspaces_processed": stats.get("company_count"),
                "embeddings_persisted": embeddings_persisted,
                "since_days": stats.get("since_days"),
            }
            metric_values.update({key: stats.get(key, 0) for key in QUALITY_METRIC_KEYS})
            if stats.get("silhouette_score") is not None:
                metric_values["silhouette_score"] = stats.get("silhouette_score")
            for name, value in metric_values.items():
                insert_metric(
                    cursor,
                    run_id,
                    name,
                    value,
                    {
                        "embedding_backend": FAQ_EMBEDDING_BACKEND,
                        "embedding_model": current_embedding_model_label(),
                        "embedding_model_configured": MODEL_NAME,
                        "workspace_id": stats.get("workspace_id"),
                        "since_days": stats.get("since_days"),
                    },
                )

    return responses

def list_suggestions_from_db(
    status: Optional[str] = None,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
    include_all: bool = False,
) -> SuggestionSummary:
    filters = []
    params: List[Any] = []
    latest_params: List[Any] = []
    latest_workspace_filter = ""
    latest_order = "finished_at DESC NULLS LAST, started_at DESC"
    if workspace_id is not None:
        latest_workspace_filter = "AND (workspace_id = %s OR workspace_id IS NULL)"
        latest_params.append(workspace_id)
    if not include_all:
        filters.append("qc.run_id = (SELECT run_id FROM latest_successful_run)")
    if status:
        filters.append("fc.status = %s")
        params.append(status)
    if workspace_id is not None:
        filters.append("fc.workspace_id = %s")
        params.append(workspace_id)
    if agent_id:
        filters.append("fc.agent_id = %s")
        params.append(agent_id)
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""

    query = f"""
        WITH latest_successful_run AS (
            SELECT run_id
            FROM {FAQ_SCHEMA}.pipeline_runs
            WHERE status = 'succeeded'
            {latest_workspace_filter}
            ORDER BY {latest_order}
            LIMIT 1
        )
        SELECT
            fc.candidate_id::text AS candidate_id,
            fc.workspace_id,
            w.name AS company_name,
            fc.agent_id::text AS agent_id,
            fc.normalized_question,
            fc.suggested_answer,
            fc.recurrence_count,
            fc.status,
            fc.created_at,
            fc.updated_at,
            COALESCE(fc.was_human_edited, false) AS was_human_edited,
            fc.last_edited_by,
            fc.last_edited_at,
            fc.candidate_metadata,
            qc.run_id::text AS run_id,
            COALESCE(ec.edit_count, 0) AS edit_count,
            COALESCE(
                array_remove(array_agg(fce.original_user_message ORDER BY fce.similarity_score DESC NULLS LAST), NULL),
                ARRAY[]::text[]
            ) AS support_examples
        FROM {FAQ_SCHEMA}.faq_candidates AS fc
        JOIN {FAQ_SCHEMA}.workspaces AS w
          ON w.workspace_id = fc.workspace_id
        LEFT JOIN {FAQ_SCHEMA}.question_clusters AS qc
          ON qc.cluster_id = fc.cluster_id
        LEFT JOIN {FAQ_SCHEMA}.faq_candidate_examples AS fce
          ON fce.candidate_id = fc.candidate_id
        LEFT JOIN (
            SELECT candidate_id, count(*) AS edit_count
            FROM {FAQ_SCHEMA}.faq_candidate_edit_events
            GROUP BY candidate_id
        ) AS ec
          ON ec.candidate_id = fc.candidate_id
        {where_clause}
        GROUP BY
            fc.candidate_id, fc.workspace_id, w.name, fc.agent_id, fc.normalized_question,
            fc.suggested_answer, fc.recurrence_count, fc.status, fc.created_at, fc.updated_at,
            fc.was_human_edited, fc.last_edited_by, fc.last_edited_at,
            fc.candidate_metadata, qc.run_id, ec.edit_count
        ORDER BY fc.created_at DESC
    """

    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(query, tuple(latest_params + params))
            rows = [dict(row) for row in cursor.fetchall()]

    suggestions = []
    for row in rows:
        metadata = row.get("candidate_metadata") or {}
        support_examples, _deduplicated = deduplicate_support_example_texts(row.get("support_examples") or [], limit=3)
        suggestions.append(
            SuggestionResponse(
                id=row["candidate_id"],
                company_id=str(row["workspace_id"]),
                company_name=row.get("company_name"),
                workspace_id=int(row["workspace_id"]),
                agent_id=row.get("agent_id"),
                question=row["normalized_question"],
                answer=row.get("suggested_answer") or "",
                cluster_size=int(row.get("recurrence_count") or 0),
                support_examples=support_examples,
                cluster_score=float(metadata.get("cluster_score") or 0.0),
                quality_tier=metadata.get("quality_tier"),
                review_reason=metadata.get("review_reason"),
                review_reason_code=metadata.get("review_reason_code"),
                generation_confidence=metadata.get("generation_confidence"),
                cluster_intent_statement=metadata.get("cluster_intent_statement"),
                knowledge_statement=metadata.get("knowledge_statement"),
                cluster_question_alignment=metadata.get("cluster_question_alignment"),
                candidate_kind=metadata.get("candidate_kind") or "full_faq",
                requires_answer_review=bool(metadata.get("requires_answer_review") or False),
                support_level=metadata.get("support_level"),
                repaired=bool(metadata.get("repaired") or False),
                since_days_used=metadata.get("since_days"),
                was_human_edited=bool(row.get("was_human_edited")),
                last_edited_by=row.get("last_edited_by"),
                last_edited_at=row.get("last_edited_at"),
                edit_count=int(row.get("edit_count") or 0),
                status=row.get("status", "pending"),
                created_at=row.get("created_at"),
                updated_at=row.get("updated_at"),
                run_id=row.get("run_id"),
            )
        )

    company_count = len({item.company_id for item in suggestions})
    total_examples = sum(item.cluster_size for item in suggestions)
    return SuggestionSummary(
        company_count=company_count,
        cluster_count=len(suggestions),
        total_examples=total_examples,
        average_cluster_size=round(total_examples / len(suggestions), 2) if suggestions else 0.0,
        silhouette_score=None,
        suggestions=suggestions,
        run_id=suggestions[0].run_id if suggestions else None,
    )

def list_workspaces_from_db() -> List[WorkspaceResponse]:
    query = f"""
        SELECT DISTINCT w.workspace_id, w.name AS workspace_name
        FROM {FAQ_SCHEMA}.workspaces AS w
        JOIN {FAQ_SCHEMA}.conversations AS c
          ON c.workspace_id = w.workspace_id
        ORDER BY w.name, w.workspace_id
    """
    with get_db_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cursor:
            cursor.execute(query)
            rows = [dict(row) for row in cursor.fetchall()]
    return [
        WorkspaceResponse(
            workspace_id=int(row["workspace_id"]),
            workspace_name=row.get("workspace_name") or f"Workspace {row['workspace_id']}",
            company_id=str(row["workspace_id"]),
        )
        for row in rows
    ]

def load_existing_faqs_by_company() -> Dict[str, List[str]]:
    if not FAQ_SKIP_EXISTING:
        return {}

    query = f"""
        SELECT workspace_id, question
        FROM {FAQ_SCHEMA}.existing_faqs
        WHERE is_active = true
          AND deleted_at IS NULL
          AND question IS NOT NULL
          AND btrim(question) <> ''
    """

    faqs_by_company: Dict[str, List[str]] = defaultdict(list)
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query)
                for workspace_id, question in cursor.fetchall():
                    clean = normalize_text(question)
                    if clean:
                        faqs_by_company[str(workspace_id)].append(clean)
    except Exception as exc:
        print(f"No se pudieron cargar FAQs existentes. Se generaran sugerencias sin deduplicar. Error: {exc}")
    return faqs_by_company

def load_previous_candidates_by_company() -> Dict[str, List[str]]:
    """
    Carga candidatos previos para evitar duplicidad entre corridas.

    Importante:
    Incluye rejected cuando FAQ_SKIP_REJECTED=true, porque el cliente pidió que
    las FAQs rechazadas no vuelvan a generarse en siguientes corridas.
    """
    statuses = ["pending", "approved", "needs_review"]
    if FAQ_SKIP_REJECTED:
        statuses.append("rejected")

    placeholders = ", ".join(["%s"] * len(statuses))
    query = f"""
        SELECT workspace_id, normalized_question
        FROM {FAQ_SCHEMA}.faq_candidates
        WHERE status IN ({placeholders})
          AND normalized_question IS NOT NULL
          AND btrim(normalized_question) <> ''
    """

    candidates_by_company: Dict[str, List[str]] = defaultdict(list)

    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, tuple(statuses))
                for workspace_id, question in cursor.fetchall():
                    clean = normalize_text(question)
                    if clean:
                        candidates_by_company[str(workspace_id)].append(clean)

    except Exception as exc:
        print(f"No se pudieron cargar candidatos previos para deduplicacion. Error: {exc}")

    return candidates_by_company

