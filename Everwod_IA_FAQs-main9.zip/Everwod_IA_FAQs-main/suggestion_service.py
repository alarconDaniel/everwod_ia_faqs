import hashlib
import json
import os
import re
import time
import uuid
from collections import Counter, defaultdict
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple, cast

from fastapi import FastAPI, HTTPException
from psycopg2.extras import Json, RealDictCursor

from faq_common import (
    DATA_DIR,
    FAQ_SCHEMA,
    configure_cors,
    fold_text,
    get_bool_env,
    get_db_connection,
    get_float_env,
    get_int_env,
    load_json,
    load_json_lines,
    normalize_question,
    normalize_text,
    save_json,
)
from faq_models import IngestRequest, SuggestionResponse, SuggestionSummary, WorkspaceResponse
from ingest_service import fetch_conversation_records, fetch_conversation_records_with_metrics



from faq_config import (
    CONVERSATIONS_PATH,
    FAQ_ALIGNMENT_PARTIAL_SIMILARITY,
    FAQ_ALIGNMENT_STRONG_SIMILARITY,
    FAQ_ALLOW_TWO_EXAMPLE_CLUSTERS,
    FAQ_CANDIDATE_HARVEST_MODE,
    FAQ_CLEANING_ENABLED,
    FAQ_CLUSTER_ALGORITHM,
    FAQ_CLUSTER_EPS,
    FAQ_DUPLICATE_THRESHOLD,
    FAQ_EMBEDDING_BACKEND,
    FAQ_ENABLE_HIERARCHICAL_FALLBACK,
    FAQ_HASH_EMBEDDING_DIM,
    FAQ_HDBSCAN_MIN_CLUSTER_SIZE,
    FAQ_HDBSCAN_MIN_SAMPLES,
    FAQ_HIGH_CONFIDENCE_THRESHOLD,
    FAQ_LLM_DEVICE,
    FAQ_LLM_ENABLED,
    FAQ_LLM_MODEL,
    FAQ_LLM_THINKING_DISABLED,
    FAQ_LLM_TORCH_DTYPE,
    FAQ_MAX_CANONICAL_ANSWER_WORDS,
    FAQ_MAX_CANONICAL_QUESTION_WORDS,
    FAQ_MIN_CLUSTER_COHESION,
    FAQ_MIN_CLUSTER_SIZE,
    FAQ_MIN_CLUSTER_SUPPORT,
    FAQ_MIN_GENERATION_CONFIDENCE,
    FAQ_MIN_QUESTION_EVIDENCE,
    FAQ_REJECT_CLUSTER_COHESION,
    FAQ_REJECT_CLUSTER_SUPPORT,
    FAQ_SKIP_EXISTING,
    FAQ_SKIP_REJECTED,
    FAQ_STRIP_EMOJIS,
    FAQ_STRIP_URLS,
    FAQ_SUPPORTED_LANGUAGES,
    FAQ_TWO_EXAMPLE_MIN_COHESION,
    MODEL_NAME,
    SUGGESTIONS_PATH,
)
from faq_candidate_filter import is_good_faq_candidate
from faq_cleaning import (
    BILINGUAL_SUPPORT_STOPWORDS,
    CHAT_NOISE_PATTERNS,
    DATE_PATTERN,
    EMAIL_PATTERN,
    EMOJI_PATTERN,
    ENGLISH_STOPWORDS,
    PHONE_PATTERN,
    PLACEHOLDER_PATTERN,
    RAW_URL_PATTERN,
    SPANISH_STOPWORDS,
    TIME_PATTERN,
    URL_PATTERN,
    clean_answer_evidence,
    clean_canonical_answer,
    clean_canonical_question,
    clean_faq_answer,
    clean_question_evidence,
    compact_canonical_answer,
    has_case_specific_time_reference,
    has_emoji,
    is_answer_evidence_usable,
    is_internal_tool_trace,
    is_low_quality_chat_style,
    normalize_chat_text,
    redact_personal_data,
    strip_emojis,
    strip_urls,
    support_tokens_multilingual,
    word_count,
)
from faq_clustering import cluster_embeddings, compute_silhouette
import faq_embeddings as _faq_embeddings
import faq_generation as _faq_generation
import faq_quality as _faq_quality
import faq_repository as _faq_repository
import faq_pipeline as _faq_pipeline

_REPO_LOAD_EXISTING_FAQS = _faq_repository.load_existing_faqs_by_company
_REPO_LOAD_PREVIOUS_CANDIDATES = _faq_repository.load_previous_candidates_by_company
_REPO_CREATE_PIPELINE_RUN = _faq_repository.create_pipeline_run
_REPO_FINISH_PIPELINE_RUN = _faq_repository.finish_pipeline_run
_REPO_INSERT_METRIC = _faq_repository.insert_metric
_REPO_PERSIST_EMBEDDING = _faq_repository.persist_embedding
_REPO_FIND_EXISTING_CANDIDATE = _faq_repository.find_existing_candidate
_REPO_PERSIST_PIPELINE_RESULTS = _faq_repository.persist_pipeline_results
_REPO_LIST_SUGGESTIONS = _faq_repository.list_suggestions_from_db
_REPO_LIST_WORKSPACES = _faq_repository.list_workspaces_from_db
_PIPELINE_PARSE_DATETIME = _faq_pipeline.parse_datetime
_PIPELINE_COMPANY_KEY = _faq_pipeline.company_key
_PIPELINE_MOST_COMMON_ANSWER = _faq_pipeline.most_common_answer
_PIPELINE_IS_EXISTING_FAQ = _faq_pipeline.is_existing_faq
_PIPELINE_MOST_COMMON_AGENT_ID = _faq_pipeline._most_common_agent_id
_PIPELINE_BUILD_COMPANY_CANDIDATES = _faq_pipeline.build_company_candidates
_PIPELINE_BUILD_SUGGESTION_CANDIDATES = _faq_pipeline.build_suggestion_candidates
_PIPELINE_SUMMARY_METRIC_PAYLOAD = _faq_pipeline.summary_metric_payload
_PIPELINE_BUILD_SUGGESTIONS = _faq_pipeline.build_suggestions
_PIPELINE_LOG_QUALITY_SUMMARY = _faq_pipeline.log_pipeline_quality_summary
_PIPELINE_RUN_SUGGESTION_PIPELINE = _faq_pipeline.run_suggestion_pipeline
_PIPELINE_LOAD_CONVERSATION_PAIRS = _faq_pipeline.load_conversation_pairs

app = FastAPI(title="Everwod FAQ Suggestion Service")
configure_cors(app)




MODELS_READY = False

EMBEDDING_MODEL = _faq_embeddings.EMBEDDING_MODEL
EMBEDDING_MODEL_READY = _faq_embeddings.EMBEDDING_MODEL_READY
EMBEDDING_BACKEND_READY = _faq_embeddings.EMBEDDING_BACKEND_READY


def _sync_embedding_module_state() -> None:
    _faq_embeddings.EMBEDDING_MODEL = EMBEDDING_MODEL
    _faq_embeddings.EMBEDDING_MODEL_READY = EMBEDDING_MODEL_READY
    _faq_embeddings.EMBEDDING_BACKEND_READY = EMBEDDING_BACKEND_READY


def _sync_embedding_facade_state() -> None:
    global EMBEDDING_MODEL, EMBEDDING_MODEL_READY, EMBEDDING_BACKEND_READY
    EMBEDDING_MODEL = _faq_embeddings.EMBEDDING_MODEL
    EMBEDDING_MODEL_READY = _faq_embeddings.EMBEDDING_MODEL_READY
    EMBEDDING_BACKEND_READY = _faq_embeddings.EMBEDDING_BACKEND_READY


def load_embedding_model() -> None:
    _sync_embedding_module_state()
    _faq_embeddings.load_embedding_model()
    _sync_embedding_facade_state()


def encode_texts(texts: List[str]) -> List[List[float]]:
    _sync_embedding_module_state()
    embeddings = _faq_embeddings.encode_texts(texts)
    _sync_embedding_facade_state()
    return embeddings


def current_embedding_model_label() -> str:
    return EMBEDDING_BACKEND_READY if EMBEDDING_BACKEND_READY != "hash" else "hash"


_as_vector = _faq_embeddings._as_vector
_normalize_vector = _faq_embeddings._normalize_vector
_dot = _faq_embeddings._dot
_mean_vector = _faq_embeddings._mean_vector
_hash_embedding = _faq_embeddings._hash_embedding


ANSWER_GENERATOR = _faq_generation.ANSWER_GENERATOR
ANSWER_GENERATOR_READY = _faq_generation.ANSWER_GENERATOR_READY


def _sync_generation_module_state() -> None:
    _faq_generation.ANSWER_GENERATOR = ANSWER_GENERATOR
    _faq_generation.ANSWER_GENERATOR_READY = ANSWER_GENERATOR_READY
    _faq_generation.FAQ_LLM_MODEL = FAQ_LLM_MODEL
    _faq_generation.FAQ_LLM_ENABLED = FAQ_LLM_ENABLED
    _faq_generation.FAQ_LLM_DEVICE = FAQ_LLM_DEVICE
    _faq_generation.FAQ_LLM_TORCH_DTYPE = FAQ_LLM_TORCH_DTYPE
    _faq_generation.FAQ_LLM_THINKING_DISABLED = FAQ_LLM_THINKING_DISABLED


def _sync_generation_facade_state() -> None:
    global ANSWER_GENERATOR, ANSWER_GENERATOR_READY
    ANSWER_GENERATOR = _faq_generation.ANSWER_GENERATOR
    ANSWER_GENERATOR_READY = _faq_generation.ANSWER_GENERATOR_READY


def _sync_quality_module_dependencies() -> None:
    _faq_quality.encode_texts = encode_texts
    _faq_quality._dot = _dot
    _faq_quality._mean_vector = _mean_vector
    _faq_quality._normalize_vector = _normalize_vector


def _resolve_llm_device(torch_module: Any) -> str:
    _sync_generation_module_state()
    return _faq_generation._resolve_llm_device(torch_module)


def _resolve_torch_dtype(torch_module: Any, device: str) -> Any:
    _sync_generation_module_state()
    return _faq_generation._resolve_torch_dtype(torch_module, device)


def load_answer_generator() -> None:
    _sync_generation_module_state()
    _faq_generation.load_answer_generator()
    _sync_generation_facade_state()


def fallback_unpublishable(reason: str, confidence: float = 0.0) -> Dict[str, Any]:
    return _faq_generation.fallback_unpublishable(reason, confidence)


def strip_thinking_text(raw_text: str) -> str:
    return _faq_generation.strip_thinking_text(raw_text)


def extract_json_object(raw_text: str) -> Optional[Dict[str, Any]]:
    _sync_quality_module_dependencies()
    return _faq_generation.extract_json_object(raw_text)


def parse_llm_faq_candidate(raw_text: str) -> Optional[Dict[str, Any]]:
    _sync_quality_module_dependencies()
    return _faq_generation.parse_llm_faq_candidate(raw_text)


def apply_chat_template_no_thinking(tokenizer: Any, messages: List[Dict[str, str]]) -> str:
    _sync_generation_module_state()
    return _faq_generation.apply_chat_template_no_thinking(tokenizer, messages)


def generate_faq_candidate_with_llm(
    company_name: Optional[str],
    questions: List[str],
    historical_answers: List[str],
    cluster_metrics: Dict[str, Any],
    recurrence: int,
) -> Dict[str, Any]:
    _sync_generation_module_state()
    _sync_quality_module_dependencies()
    generation = _faq_generation.generate_faq_candidate_with_llm(
        company_name, questions, historical_answers, cluster_metrics, recurrence
    )
    _sync_generation_facade_state()
    return generation


def repair_faq_candidate_with_llm(
    company_name: Optional[str],
    generation: Dict[str, Any],
    rejection_reason: str,
    questions: List[str],
    historical_answers: List[str],
    cluster_metrics: Dict[str, Any],
    cluster_intent_statement: Optional[str] = None,
    alignment_reason: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    _sync_generation_module_state()
    _sync_quality_module_dependencies()
    repaired = _faq_generation.repair_faq_candidate_with_llm(
        company_name,
        generation,
        rejection_reason,
        questions,
        historical_answers,
        cluster_metrics,
        cluster_intent_statement,
        alignment_reason,
    )
    _sync_generation_facade_state()
    return repaired


def is_valid_canonical_question(question: str) -> bool:
    _sync_quality_module_dependencies()
    return _faq_quality.is_valid_canonical_question(question)


def is_valid_canonical_answer(answer: str) -> bool:
    _sync_quality_module_dependencies()
    return _faq_quality.is_valid_canonical_answer(answer)


def is_valid_knowledge_statement(statement: str) -> bool:
    _sync_quality_module_dependencies()
    return _faq_quality.is_valid_knowledge_statement(statement)


def clean_statement(text: str, company_name: Optional[str] = None) -> str:
    return _faq_quality.clean_statement(text, company_name=company_name)


def is_valid_cluster_intent_statement(statement: str) -> bool:
    return _faq_quality.is_valid_cluster_intent_statement(statement)


def is_question_answer_aligned(question: str, answer: str, knowledge_statement: str = "") -> Tuple[bool, str]:
    _sync_quality_module_dependencies()
    return _faq_quality.is_question_answer_aligned(question, answer, knowledge_statement)


SUPPORT_STOPWORDS = _faq_quality.SUPPORT_STOPWORDS
QUALITY_METRIC_KEYS = _faq_quality.QUALITY_METRIC_KEYS


def support_tokens(text: str) -> set[str]:
    return _faq_quality.support_tokens(text)


def deduplicate_support_example_texts(examples: Iterable[str], limit: int = 3) -> Tuple[List[str], int]:
    return _faq_quality.deduplicate_support_example_texts(examples, limit=limit)


def select_support_examples_for_candidate(
    question: str,
    examples: List[Dict[str, Any]],
    limit: int = 3,
) -> Tuple[List[str], int]:
    _sync_quality_module_dependencies()
    return _faq_quality.select_support_examples_for_candidate(question, examples, limit=limit)


def is_prudent_answer(answer: str) -> bool:
    return _faq_quality.is_prudent_answer(answer)


def is_generation_supported_by_evidence(
    generation: Dict[str, Any],
    questions: List[str],
    answers: List[str],
) -> Dict[str, Any]:
    _sync_quality_module_dependencies()
    return _faq_quality.is_generation_supported_by_evidence(generation, questions, answers)


def validate_generated_candidate(candidate: Dict[str, Any]) -> Tuple[bool, str]:
    _sync_quality_module_dependencies()
    return _faq_quality.validate_generated_candidate(candidate)


def classify_quality_tier(
    generation: Dict[str, Any],
    cluster_cohesion: float,
    support: float,
    valid_answer_count: int,
    review_reasons: Optional[List[str]] = None,
) -> Tuple[str, Optional[str]]:
    return _faq_quality.classify_quality_tier(
        generation,
        cluster_cohesion=cluster_cohesion,
        support=support,
        valid_answer_count=valid_answer_count,
        review_reasons=review_reasons,
    )


def build_prudent_answer(questions: List[str], categories: set[str]) -> Optional[str]:
    return _faq_quality.build_prudent_answer(questions, categories)


def build_prudent_question(questions: List[str], categories: set[str]) -> Optional[str]:
    return _faq_quality.build_prudent_question(questions, categories)


def recover_unsupported_generation_for_review(
    generation: Dict[str, Any],
    cluster_questions: List[str],
    intent_categories: set[str],
    question_embeddings: List[List[float]],
    cluster_center: List[float],
) -> Optional[Dict[str, Any]]:
    _sync_quality_module_dependencies()
    return _faq_quality.recover_unsupported_generation_for_review(
        generation, cluster_questions, intent_categories, question_embeddings, cluster_center
    )


def can_persist_generation_for_review(
    generation: Dict[str, Any],
    rejection_reason: str,
    intent_categories: set[str],
) -> Tuple[bool, Optional[str], Optional[str]]:
    _sync_quality_module_dependencies()
    return _faq_quality.can_persist_generation_for_review(generation, rejection_reason, intent_categories)


def cluster_intent_categories(questions: List[str]) -> set[str]:
    return _faq_quality.cluster_intent_categories(questions)


def is_mixed_intent_cluster(questions: List[str]) -> Tuple[bool, str]:
    return _faq_quality.is_mixed_intent_cluster(questions)


def derive_cluster_intent_statement(questions: List[str]) -> str:
    return _faq_quality.derive_cluster_intent_statement(questions)


def _primary_alignment_categories(categories: set[str]) -> set[str]:
    return _faq_quality._primary_alignment_categories(categories)


def is_canonical_question_aligned_with_cluster(
    canonical_question: str,
    cluster_questions: List[str],
    question_embeddings: Optional[List[List[float]]] = None,
    cluster_center: Optional[List[float]] = None,
) -> Dict[str, Any]:
    _sync_quality_module_dependencies()
    return _faq_quality.is_canonical_question_aligned_with_cluster(
        canonical_question,
        cluster_questions,
        question_embeddings=question_embeddings,
        cluster_center=cluster_center,
    )


def calculate_cluster_score(
    recurrence: int,
    cluster_cohesion: float,
    generation_confidence: float,
    valid_question_count: int,
    valid_answer_count: int,
) -> float:
    return _faq_quality.calculate_cluster_score(
        recurrence, cluster_cohesion, generation_confidence, valid_question_count, valid_answer_count
    )


def empty_quality_metrics() -> Dict[str, int]:
    return _faq_quality.empty_quality_metrics()


def _sync_repository_module_dependencies() -> None:
    _faq_repository.encode_texts = encode_texts
    _faq_repository.current_embedding_model_label = current_embedding_model_label
    _faq_repository.deduplicate_support_example_texts = deduplicate_support_example_texts
    _faq_repository.QUALITY_METRIC_KEYS = QUALITY_METRIC_KEYS
    _faq_repository.FAQ_EMBEDDING_BACKEND = FAQ_EMBEDDING_BACKEND
    _faq_repository.MODEL_NAME = MODEL_NAME


def _sync_pipeline_module_dependencies() -> None:
    _sync_generation_module_state()
    _sync_quality_module_dependencies()
    _sync_repository_module_dependencies()
    _faq_pipeline.encode_texts = encode_texts
    _faq_pipeline.cluster_embeddings = cluster_embeddings
    _faq_pipeline.compute_silhouette = compute_silhouette
    _faq_pipeline._dot = _dot
    _faq_pipeline._mean_vector = _mean_vector
    _faq_pipeline._normalize_vector = _normalize_vector
    _faq_pipeline.current_embedding_model_label = current_embedding_model_label
    _faq_pipeline.generate_faq_candidate_with_llm = generate_faq_candidate_with_llm
    _faq_pipeline.repair_faq_candidate_with_llm = repair_faq_candidate_with_llm
    _faq_pipeline.ANSWER_GENERATOR = ANSWER_GENERATOR
    _faq_pipeline.FAQ_LLM_MODEL = FAQ_LLM_MODEL
    _faq_pipeline.FAQ_LLM_ENABLED = FAQ_LLM_ENABLED
    _faq_pipeline.FAQ_LLM_THINKING_DISABLED = FAQ_LLM_THINKING_DISABLED
    _faq_pipeline.is_existing_faq = is_existing_faq
    _faq_pipeline.load_existing_faqs_by_company = load_existing_faqs_by_company
    _faq_pipeline.load_previous_candidates_by_company = load_previous_candidates_by_company
    _faq_pipeline.create_pipeline_run = create_pipeline_run
    _faq_pipeline.finish_pipeline_run = finish_pipeline_run
    _faq_pipeline.persist_pipeline_results = persist_pipeline_results
    _faq_pipeline.fetch_conversation_records_with_metrics = fetch_conversation_records_with_metrics
    _faq_pipeline.save_json = save_json


def parse_datetime(value: Any) -> Optional[datetime]:
    return _PIPELINE_PARSE_DATETIME(value)


def company_key(item: Dict[str, Any]) -> str:
    return _PIPELINE_COMPANY_KEY(item)


def most_common_answer(answers: List[str], protected_terms: Optional[List[str]] = None) -> str:
    return _PIPELINE_MOST_COMMON_ANSWER(answers, protected_terms=protected_terms)


def load_existing_faqs_by_company() -> Dict[str, List[str]]:
    _sync_repository_module_dependencies()
    return _REPO_LOAD_EXISTING_FAQS()


def load_previous_candidates_by_company() -> Dict[str, List[str]]:
    _sync_repository_module_dependencies()
    return _REPO_LOAD_PREVIOUS_CANDIDATES()


def is_existing_faq(question: str, existing_questions: List[str]) -> bool:
    _sync_pipeline_module_dependencies()
    return _PIPELINE_IS_EXISTING_FAQ(question, existing_questions)


def _most_common_agent_id(items: Iterable[Dict[str, Any]]) -> Optional[str]:
    return _PIPELINE_MOST_COMMON_AGENT_ID(items)


def build_company_candidates(
    conversations: List[Dict[str, Any]],
    existing_questions: Optional[List[str]] = None,
    previous_candidate_questions: Optional[List[str]] = None,
    run_id: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    _sync_pipeline_module_dependencies()
    return _PIPELINE_BUILD_COMPANY_CANDIDATES(
        conversations,
        existing_questions=existing_questions,
        previous_candidate_questions=previous_candidate_questions,
        run_id=run_id,
    )


def build_suggestion_candidates(
    conversations: List[Dict[str, Any]],
    existing_faqs_by_company: Optional[Dict[str, List[str]]] = None,
    previous_candidates_by_company: Optional[Dict[str, List[str]]] = None,
    run_id: Optional[str] = None,
    ingest_metrics: Optional[Dict[str, Any]] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    _sync_pipeline_module_dependencies()
    return _PIPELINE_BUILD_SUGGESTION_CANDIDATES(
        conversations,
        existing_faqs_by_company=existing_faqs_by_company,
        previous_candidates_by_company=previous_candidates_by_company,
        run_id=run_id,
        ingest_metrics=ingest_metrics,
    )


SUMMARY_METRIC_FIELDS = _faq_pipeline.SUMMARY_METRIC_FIELDS


def summary_metric_payload(stats: Dict[str, Any]) -> Dict[str, Any]:
    return _PIPELINE_SUMMARY_METRIC_PAYLOAD(stats)


def build_suggestions(conversations: List[Dict[str, Any]]) -> SuggestionSummary:
    _sync_pipeline_module_dependencies()
    return _PIPELINE_BUILD_SUGGESTIONS(conversations)


def create_pipeline_run(parameters: Dict[str, Any], workspace_id: Optional[int] = None) -> str:
    _sync_repository_module_dependencies()
    return _REPO_CREATE_PIPELINE_RUN(parameters, workspace_id=workspace_id)


def finish_pipeline_run(run_id: str, status: str, notes: Optional[str] = None) -> None:
    _sync_repository_module_dependencies()
    _REPO_FINISH_PIPELINE_RUN(run_id, status, notes=notes)


def insert_metric(
    cursor: Any,
    run_id: str,
    name: str,
    value: Optional[float],
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    _sync_repository_module_dependencies()
    _REPO_INSERT_METRIC(cursor, run_id, name, value, metadata=metadata)


def persist_embedding(cursor: Any, candidate: Dict[str, Any], example: Dict[str, Any]) -> int:
    _sync_repository_module_dependencies()
    return _REPO_PERSIST_EMBEDDING(cursor, candidate, example)


def find_existing_candidate(cursor: Any, candidate: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    _sync_repository_module_dependencies()
    return _REPO_FIND_EXISTING_CANDIDATE(cursor, candidate)


def persist_pipeline_results(
    run_id: str,
    candidates: List[Dict[str, Any]],
    stats: Dict[str, Any],
) -> List[SuggestionResponse]:
    _sync_repository_module_dependencies()
    return _REPO_PERSIST_PIPELINE_RESULTS(run_id, candidates, stats)


def list_suggestions_from_db(
    status: Optional[str] = None,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
    include_all: bool = False,
) -> SuggestionSummary:
    _sync_repository_module_dependencies()
    return _REPO_LIST_SUGGESTIONS(
        status=status,
        workspace_id=workspace_id,
        agent_id=agent_id,
        include_all=include_all,
    )


def list_workspaces_from_db() -> List[WorkspaceResponse]:
    _sync_repository_module_dependencies()
    return _REPO_LIST_WORKSPACES()


def log_pipeline_quality_summary(stats: Dict[str, Any]) -> None:
    _sync_pipeline_module_dependencies()
    _PIPELINE_LOG_QUALITY_SUMMARY(stats)


def run_suggestion_pipeline(request: Optional[IngestRequest] = None) -> SuggestionSummary:
    _sync_pipeline_module_dependencies()
    _faq_pipeline.build_suggestion_candidates = (
        build_suggestion_candidates
        if build_suggestion_candidates is not _BUILD_SUGGESTION_CANDIDATES_WRAPPER
        else _PIPELINE_BUILD_SUGGESTION_CANDIDATES
    )
    _faq_pipeline.persist_pipeline_results = (
        persist_pipeline_results
        if persist_pipeline_results is not _PERSIST_PIPELINE_RESULTS_WRAPPER
        else _REPO_PERSIST_PIPELINE_RESULTS
    )
    return _PIPELINE_RUN_SUGGESTION_PIPELINE(request)


def load_conversation_pairs() -> List[Dict[str, Any]]:
    return _PIPELINE_LOAD_CONVERSATION_PAIRS()


_BUILD_SUGGESTION_CANDIDATES_WRAPPER = build_suggestion_candidates
_PERSIST_PIPELINE_RESULTS_WRAPPER = persist_pipeline_results








def load_models() -> None:
    global MODELS_READY
    if MODELS_READY:
        return
    load_embedding_model()
    load_answer_generator()
    MODELS_READY = True











































































































































































@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "service": "suggestion",
        "source_schema": FAQ_SCHEMA,
        "embedding_model": MODEL_NAME,
        "embedding_backend": EMBEDDING_BACKEND_READY,
        "answer_model": FAQ_LLM_MODEL if ANSWER_GENERATOR else "historical_fallback",
        "thinking_disabled": FAQ_LLM_THINKING_DISABLED,
    }


@app.get("/workspaces", response_model=List[WorkspaceResponse])
def get_workspaces() -> List[WorkspaceResponse]:
    return list_workspaces_from_db()


@app.post("/suggest", response_model=SuggestionSummary)
def suggest(request: Optional[IngestRequest] = None) -> SuggestionSummary:
    try:
        return run_suggestion_pipeline(request)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"No se pudo generar sugerencias: {exc}") from exc


@app.get("/suggestions", response_model=SuggestionSummary)
def get_suggestions(
    status: Optional[str] = None,
    workspace_id: Optional[int] = None,
    agent_id: Optional[str] = None,
    include_all: bool = False,
) -> SuggestionSummary:
    if status and status not in {"pending", "approved", "rejected", "needs_review"}:
        raise HTTPException(status_code=400, detail="Invalid status filter.")
    return list_suggestions_from_db(
        status=status,
        workspace_id=workspace_id,
        agent_id=agent_id,
        include_all=include_all,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("suggestion_service:app", host="127.0.0.1", port=8003, log_level="info")
